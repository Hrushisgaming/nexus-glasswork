#!/usr/bin/env bash
# Shared helpers for the macOS CI kit. Written to work on macOS bash 3.2 too.
set -euo pipefail

: "${CCACHE_DIR:=$HOME/Library/Caches/ccache}"
: "${CACHE_TAG:=build-cache}"          # GitHub release that holds fallback cache tarballs
: "${WORKFLOW_FILE:=build-macos.yml}"
export CCACHE_DIR
HB_DL="$HOME/Library/Caches/Homebrew/downloads"

log()  { echo "[ci] $*" >&2; }
warn() { echo "::warning::$*" >&2; }

# retry CMD...   (RETRIES=3 by default, backoff 10s, 20s, 40s ...)
retry() {
  local max="${RETRIES:-3}" n=1 wait=10
  until "$@"; do
    if (( n >= max )); then return 1; fi
    log "attempt $n/$max failed: $*  (retrying in ${wait}s)"
    sleep "$wait"; wait=$((wait * 2)); n=$((n + 1))
  done
}

have_zstd()  { command -v zstd >/dev/null 2>&1; }
compressor() { if have_zstd; then echo "zstd -T0 -3 -q"; else echo "gzip -1"; fi; }
ext()        { if have_zstd; then echo "tar.zst"; else echo "tar.gz"; fi; }

# tar_pack OUT BASE [LISTFILE]  - pack BASE, or only the files listed (relative to BASE)
tar_pack() {
  local out="$1" base="$2" list="${3:-}"
  mkdir -p "$(dirname "$out")"
  if [[ -n "$list" ]]; then
    tar -C "$base" -T "$list" -cf - | $(compressor) > "$out"
  else
    tar -C "$base" -cf - . | $(compressor) > "$out"
  fi
}

# tar_unpack ARCHIVE DEST
tar_unpack() {
  local in="$1" dest="$2"; mkdir -p "$dest"
  case "$in" in
    *.zst) zstd -dc "$in" ;;
    *.gz)  gzip -dc "$in" ;;
    *) log "unknown archive type: $in"; return 1 ;;
  esac | tar -C "$dest" -xf -
}

file_size() { stat -f%z "$1" 2>/dev/null || stat -c%s "$1"; }
