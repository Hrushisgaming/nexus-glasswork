#!/usr/bin/env bash
# Install Homebrew deps with retries; if the bundle fails, fall back to one formula at a time.
# Optional formulae may fail: LMMS then builds without that feature (its CMake auto-detects them).
source "$(dirname "$0")/common.sh"
export HOMEBREW_NO_AUTO_UPDATE=1 HOMEBREW_NO_INSTALL_UPGRADE=1 \
       HOMEBREW_NO_INSTALLED_DEPENDENTS_CHECK=1 HOMEBREW_NO_ANALYTICS=1
OPTIONAL=" carla jack fltk libgig lilv lv2 fluid-synth portaudio sdl2 stk "
if retry brew bundle install --verbose; then
  log "brew bundle ok"
else
  warn "brew bundle failed; installing formulae one by one"
  for f in $(grep -E '^brew "' Brewfile | cut -d'"' -f2); do
    if ! retry brew install "$f"; then
      if [[ "$OPTIONAL" == *" $f "* ]]; then
        warn "optional dependency '$f' failed; building without it"
      else
        echo "::error::required dependency '$f' failed to install"; exit 1;
      fi
    fi
  done
fi
retry pipx install dmgbuild || warn "dmgbuild missing: packaging a .dmg will fail, but the .app still builds"
pipx ensurepath || true
export PATH="$HOME/.local/bin:$PATH"
