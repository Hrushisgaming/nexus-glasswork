#!/usr/bin/env bash
# Fallback cache layers used when GitHub's actions/cache misses, is full, or is down.
#   L2: tarball in a rolling GitHub release (tag $CACHE_TAG). No 10 GB repo-cache limit; 2 GiB per file.
#   L3: "<name>-merged" artifact from the last successful run of this workflow.
# Needs: gh CLI + GH_TOKEN in the environment.
source "$(dirname "$0")/common.sh"
work="$(mktemp -d)"; trap 'rm -rf "$work"' EXIT

release_restore() {   # NAME DEST
  local name="$1" dest="$2" f
  mkdir -p "$work/rel"
  gh release download "$CACHE_TAG" -p "$name.tar.*" -D "$work/rel" --clobber >/dev/null 2>&1 || return 1
  f="$(ls "$work"/rel/"$name".tar.* 2>/dev/null | head -1 || true)"
  [[ -n "$f" ]] || return 1
  tar_unpack "$f" "$dest" && log "restored '$name' from release '$CACHE_TAG'"
}

artifact_restore() {  # NAME DEST
  local name="$1" dest="$2" id f
  for id in $(gh run list --workflow "$WORKFLOW_FILE" --status success --limit 10 \
                --json databaseId -q '.[].databaseId' 2>/dev/null || true); do
    rm -rf "$work/art"; mkdir -p "$work/art"
    if gh run download "$id" -n "$name-merged" -D "$work/art" >/dev/null 2>&1; then
      f="$(ls "$work"/art/*.tar.* 2>/dev/null | head -1 || true)"
      if [[ -n "$f" ]] && tar_unpack "$f" "$dest"; then
        log "restored '$name' from artifact of run $id"; return 0
      fi
    fi
  done
  return 1
}

release_save() {      # NAME SRC
  local name="$1" src="$2" out size
  out="$work/$name.$(ext)"
  tar_pack "$out" "$src"
  size="$(file_size "$out")"
  if (( size > 1950 * 1024 * 1024 )); then warn "$name is $((size/1048576)) MB, over the 2 GiB release-asset limit; skipping release save"; return 1; fi
  gh release view "$CACHE_TAG" >/dev/null 2>&1 || \
    gh release create "$CACHE_TAG" --prerelease --title "Build cache (automatic)" \
      --notes "Rolling cache tarballs used by CI as a fallback. Safe to delete; they are rebuilt."
  gh release delete-asset "$CACHE_TAG" "$name.tar.gz"  -y >/dev/null 2>&1 || true
  gh release delete-asset "$CACHE_TAG" "$name.tar.zst" -y >/dev/null 2>&1 || true
  retry gh release upload "$CACHE_TAG" "$out" --clobber
  log "saved '$name' ($((size/1048576)) MB) to release '$CACHE_TAG'"
}

delta_pack() {        # NAME DIR MARKER OUTDIR  - pack only files newer than MARKER
  local name="$1" dir="$2" marker="$3" outdir="$4"
  mkdir -p "$outdir"
  ( cd "$dir" && find . -type f -newer "$marker" ) > "$work/list" || true
  if [[ -s "$work/list" ]]; then
    tar_pack "$outdir/$name.$(ext)" "$dir" "$work/list"
    log "delta '$name': $(wc -l < "$work/list" | tr -d ' ') files"
  else
    log "delta '$name': nothing new"
  fi
}

merge_deltas() {      # SRCDIR DEST  - unpack every tarball under SRCDIR into DEST (ccache is content-addressed, so overlaying is safe)
  local f
  find "$1" -name '*.tar.*' 2>/dev/null | while read -r f; do tar_unpack "$f" "$2" && log "merged $(basename "$f")"; done
}

case "${1:?usage: cache.sh restore-any|release-save|delta-pack|merge-deltas ...}" in
  restore-any)    shift; release_restore "$1" "$2" || artifact_restore "$1" "$2" || { log "no fallback cache for '$1' (cold start)"; exit 1; } ;;
  release-save)   shift; release_save "$@" ;;
  delta-pack)     shift; delta_pack "$@" ;;
  merge-deltas)   shift; merge_deltas "$@" ;;
  *) echo "unknown command $1" >&2; exit 2 ;;
esac
