#!/usr/bin/env bash
# Final stage: merge every stage's cache delta, check all stages finished, then do the
# full build (nearly all ccache hits) and package the .dmg. Writes result/result.txt:
# ok | partial (ran out of time budget, resume will continue) | failed
source "$(dirname "$0")/common.sh"
here="$(cd "$(dirname "$0")" && pwd)"
: "${ARCH:?}" "${NSHARDS:?}" "${BUDGET:?}" "${GITHUB_RUN_ID:?}"
mkdir -p deltas statuses result dist
echo failed > result/result.txt # pessimistic default

# 1. Harvest artifacts downloaded via actions/download-artifact (if any)
if [ -d "artifacts" ]; then
  find artifacts -type f -name "delta-*" -exec cp {} deltas/ \; 2>/dev/null || true
  find artifacts -type f -name "status-*" -exec cp {} statuses/ \; 2>/dev/null || true
fi

# 2. Fallback to direct gh run downloads
gh run download "$GITHUB_RUN_ID" -p "delta-${ARCH}-*" -D deltas >/dev/null 2>&1 || log "no deltas found via gh"
gh run download "$GITHUB_RUN_ID" -p "status-${ARCH}-*" -D statuses >/dev/null 2>&1 || log "no statuses found via gh"

"$here/cache.sh" merge-deltas deltas "$CCACHE_DIR"
touch "$RUNNER_TEMP/cache-marker"

expected=$((NSHARDS + 1)) # core + shards
complete=$(grep -rl '^complete' statuses 2>/dev/null | wc -l | tr -d ' ')
partial=$(grep -rl '^partial' statuses 2>/dev/null | wc -l | tr -d ' ')
log "stages complete: $complete/$expected, partial: $partial"

if (( complete < expected )); then
  if (( partial > 0 )); then echo partial > result/result.txt; fi
  exit 0
fi

"$here/build.sh" build ALL "$BUDGET" status.txt || true
case "$(cat status.txt 2>/dev/null || echo failed)" in
  complete) "$here/build.sh" package && echo ok > result/result.txt ;;
  partial) echo partial > result/result.txt ;;
esac
