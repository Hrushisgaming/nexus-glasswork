#!/usr/bin/env bash
# Usage: build.sh configure | list-targets | shard SHARD N | build LISTFILE|ALL BUDGET_MIN STATUSFILE | package
# Needs env: ARCH (arm64|x86_64), TARGET_OS (macOS deployment target)
source "$(dirname "$0")/common.sh"
BUILD_DIR="${BUILD_DIR:-build}"
JOBS="${CMAKE_BUILD_PARALLEL_LEVEL:-$(sysctl -n hw.logicalcpu)}"

configure() {
  : "${ARCH:?}" "${TARGET_OS:?}"
  local gw=ON; [[ "${GLASSWORK:-on}" == "off" ]] && gw=OFF   # safe mode: skip Glasswork's own plugins
  local args="-DCMAKE_BUILD_TYPE=RelWithDebInfo -DTARGET_UARCH=official -DWANT_QT6=ON -DUSE_COMPILE_CACHE=ON -DUSE_WERROR=OFF -DWANT_GLASSWORK=$gw"
  ccache --zero-stats || true
  cmake -S . -B "$BUILD_DIR" $args -DCMAKE_OSX_ARCHITECTURES="$ARCH" \
        -DCMAKE_OSX_DEPLOYMENT_TARGET="$TARGET_OS" ${EXTRA_CMAKE_OPTS:-} || {
    warn "configure failed; retrying once from a clean build dir"
    rm -rf "$BUILD_DIR"
    cmake -S . -B "$BUILD_DIR" $args -DCMAKE_OSX_ARCHITECTURES="$ARCH" \
          -DCMAKE_OSX_DEPLOYMENT_TARGET="$TARGET_OS" ${EXTRA_CMAKE_OPTS:-}
  }
}

list_targets() {   # every real build target except the core (built in its own stage)
  cmake --build "$BUILD_DIR" --target help | sed -n 's/^\.\.\. //p' | awk '{print $1}' \
   | grep -Ev '\.(o|i|s)$|^(all|clean|depend|edit_cache|rebuild_cache|install|install/local|install/strip|list_install_components|package|package_source|test|help|uninstall|lmms|dist|distclean|update-locales)$|\.ts$|^(Continuous|Experimental|Nightly)|^cmake_' \
   | sort
}

shard_targets() { list_targets | awk -v s="$1" -v n="$2" 'NR % n == s'; }   # round-robin split

# run_with_budget MINUTES CMD...  - SIGTERM the build when the budget runs out, so the job can still save its cache
run_with_budget() {
  local mins="$1"; shift
  rm -f .budget-hit
  "$@" & local pid=$!
  ( sleep $((mins * 60)); touch .budget-hit; pkill -TERM -P "$pid" 2>/dev/null; kill -TERM "$pid" 2>/dev/null ) & local wd=$!
  local rc=0; wait "$pid" || rc=$?
  kill "$wd" 2>/dev/null || true
  return "$rc"
}

build() {          # LISTFILE|ALL  BUDGET_MIN  STATUSFILE      status: complete | partial | failed
  local list="$1" budget="$2" status="$3" targets="" rc=0
  mkdir -p "$(dirname "$status")"
  if [[ "$list" == "ALL" ]]; then targets=""
  elif [[ -s "$list" ]]; then targets="--target $(tr '\n' ' ' < "$list")"
  else echo complete > "$status"; log "nothing to build in this shard"; return 0; fi
  run_with_budget "$budget" cmake --build "$BUILD_DIR" --parallel "$JOBS" $targets || rc=$?
  if   [[ -f .budget-hit ]]; then echo partial  > "$status"; warn "time budget (${budget} min) hit; partial progress is cached"; return 0
  elif (( rc == 0 ));        then echo complete > "$status"
  else echo failed > "$status"; return "$rc"; fi
}

package() {
  cmake --build "$BUILD_DIR" --target package
  mkdir -p dist && cp "$BUILD_DIR"/*.dmg dist/
}

case "${1:?usage}" in
  configure)    configure ;;
  list-targets) list_targets ;;
  shard)        shift; shard_targets "$@" ;;
  build)        shift; build "$@" ;;
  package)      package ;;
  *) echo "unknown command $1" >&2; exit 2 ;;
esac
