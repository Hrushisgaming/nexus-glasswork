#!/usr/bin/env python3
"""Add effect chains (reverb, delay, bitcrush, compressor) to the Blocky presets using LMMS's built-in effects.
Run after gen_presets.py and gen_fm_acid_presets.py, from the repo root.  Wet = how much effect is mixed in (0..1)."""
import glob, xml.etree.ElementTree as ET

def effect(plugin, ctrl_tag, wet, **attrs):
    return dict(plugin=plugin, tag=ctrl_tag, wet=wet, attrs=attrs)

def reverb(wet, size=0.9, color=10000): return effect('reverbsc', 'ReverbSCControls', wet, input_gain=0, size=size, color=color, output_gain=0)
def delay(wet, time=0.375, fb=0.35):    return effect('delay', 'Delay', wet, DelayTimeSamples=time, FeebackAmount=fb, LfoFrequency=2, LfoAmount=0, OutGain=0)
def crush(wet, levels, rate):           return effect('bitcrush', 'bitcrushcontrols', wet, ingain=0, innoise=0, outgain=0, outclip=0, rate=rate, stereodiff=0, levels=levels, rateon=1, depthon=1)
def chorus(wet, rate=0.6, depth=5.0, delay=14.0, fb=0.0, width=100.0): return effect('glassworkchorus', 'GlassworkChorusControls', wet, rate=rate, depth=depth, delay=delay, feedback=fb, width=width)
def pump(rate=2, depth=70, curve=50, shift=0): return effect('glassworkpump', 'GlassworkPumpControls', 1.0, rate=rate, depth=depth, curve=curve, shift=shift)
def comp(thr=-14, ratio=4, att=8, rel=140): return effect('compressor', 'CompressorControls', 1.0, threshold=thr, ratio=ratio, attack=att, release=rel, knee=6)

BASSES = ["Blocky 808 Sub","Blocky Reese Growl","Blocky Slap Bass","Blocky Hellfire Bass","Blocky Rubber Bass","Blocky Bouncy Bass",
          "Blocky FM Slap Bass","Blocky Acid Bass","Blocky Sub 303","Blocky Rubber Slide"]
CHAINS = {n: [comp()] for n in BASSES}
CHAINS.update({
 "Blocky Hellfire Bass": [crush(0.35, 24, 11000), comp()],
 "Blocky Glass Bell": [reverb(0.30, 0.90)], "Blocky Music Box": [reverb(0.30, 0.90)], "Blocky Marimba": [reverb(0.20, 0.75)],
 "Blocky Warm Pad": [reverb(0.40, 0.93)], "Blocky Choir Pad": [reverb(0.45, 0.95)], "Blocky Dark Drone": [reverb(0.40, 0.95)],
 "Blocky Soft Keys": [reverb(0.25, 0.85)], "Blocky FM Glock": [reverb(0.30, 0.90)], "Blocky FM Tines": [reverb(0.25, 0.85)],
 "Blocky FM Vibes": [reverb(0.30, 0.90)], "Blocky FM Brass Hit": [reverb(0.15, 0.80)],
 "Blocky Crash Cymbal": [reverb(0.20, 0.80)], "Blocky Ride Cymbal": [reverb(0.20, 0.80)], "Blocky Splash Cymbal": [reverb(0.20, 0.80)],
 "Blocky Snappy Snare": [reverb(0.20, 0.70)], "Blocky Clap": [reverb(0.25, 0.75)], "Blocky Tom": [reverb(0.15, 0.75)],
 "Blocky Impact Boom": [reverb(0.40, 0.95)], "Blocky Riser": [reverb(0.35, 0.90)],
 "Blocky Orchestra Hit": [reverb(0.30, 0.90)], "Blocky Brass Stab": [reverb(0.15, 0.80)], "Blocky Pizzicato Strings": [reverb(0.15, 0.80)],
 "Blocky Bright Pluck": [delay(0.20, 0.25, 0.30), reverb(0.12, 0.80)],
 "Blocky Supersaw Lead": [delay(0.25, 0.375, 0.35), reverb(0.15, 0.85)],
 "Blocky Distorted Lead": [delay(0.20, 0.375, 0.30)], "Blocky Squelch Lead": [delay(0.20, 0.375, 0.30)],
 "Blocky Chip Lead": [crush(0.50, 48, 18000), delay(0.20, 0.375, 0.30)],
 "Blocky Chip Bass": [crush(0.50, 64, 22000), comp()],
})
CHAINS["Blocky Hellfire Bass"] = [crush(0.35, 24, 11000), comp()]
CHAINS.update({
 "GW Supersaw Lead": [chorus(0.35), delay(0.22, 0.375, 0.32), reverb(0.15, 0.85)],
 "GW Trance Pluck":  [delay(0.30, 0.375, 0.4), reverb(0.18, 0.85)],
 "GW Wide Pad":      [chorus(0.5, 0.35, 7.0, 18.0), reverb(0.4, 0.93)],
 "GW Hoover":        [chorus(0.4, 0.8, 6.0), reverb(0.2, 0.85)],
 "GW Pump Pad":      [pump(2, 75, 55), chorus(0.45, 0.4, 6.0, 16.0), reverb(0.35, 0.92)],
 "GW Harp":          [reverb(0.3, 0.9)], "GW Nylon Guitar": [reverb(0.2, 0.8)], "GW Bright Pluck": [delay(0.2, 0.375, 0.3), reverb(0.15, 0.8)],
 "GW Muted Pluck":   [reverb(0.1, 0.7)], "GW String Bass": [comp()],
 "GW Closed Hat": [], "GW Open Hat": [reverb(0.12, 0.7)], "GW Crash": [reverb(0.2, 0.85)], "GW Ride": [reverb(0.15, 0.8)],
 "GW Splash": [reverb(0.2, 0.8)], "GW Cowbell": [reverb(0.1, 0.7)], "GW Shaker": [],
 "GW Reese": [comp()], "GW Sub Pump": [pump(2, 65, 50), comp()], "GW Slap Funk": [comp()],
 "GW Acid Squelch": [comp()], "GW Hellfire": [crush(0.3, 24, 12000), comp()], "GW Rubber": [comp()],
})

def build_fxchain(parent, chain):
    for e in list(parent): parent.remove(e)
    parent.set('numofeffects', str(len(chain))); parent.set('enabled', '1')
    for c in chain:
        eff = ET.SubElement(parent, 'effect', {'autoquit_numerator': '4', 'autoquit_denominator': '4', 'syncmode': '0',
                                             'autoquit': '1', 'name': c['plugin'], 'wet': str(c['wet']), 'on': '1'})
        ET.SubElement(eff, c['tag'], {k: str(v) for k, v in c['attrs'].items()})
        ET.SubElement(eff, 'key')

done, missing = 0, []
for fn in sorted(glob.glob('data/presets/*/*.xpf')):
    tree = ET.parse(fn); root = tree.getroot()
    its = root.find('instrumenttracksettings')
    if its is None: continue
    name = its.get('name')
    chain = CHAINS.get(name)
    if chain is None or not chain: continue
    fx = root.find('.//fxchain')
    if fx is None: missing.append(name); continue
    build_fxchain(fx, chain)
    head = open(fn).read().split('\n', 2)
    ET.indent(tree); tree.write(fn, encoding='utf-8', xml_declaration=True)
    doctype = 'multimedia-project' if root.tag == 'multimedia-project' else 'lmms-project'
    s = open(fn).read().replace("<?xml version='1.0' encoding='utf-8'?>", '<?xml version="1.0"?>\n<!DOCTYPE %s>' % doctype, 1)
    open(fn, 'w').write(s); done += 1
print(done, 'presets got effect chains; no fxchain element in:', missing or 'none')
def _name(f):
    r = ET.parse(f).getroot().find('instrumenttracksettings')
    return r.get('name') if r is not None else None
unused = [n for n in CHAINS if n not in {_name(f) for f in glob.glob('data/presets/*/*.xpf')}]
print('chain names with no matching preset:', unused or 'none')
