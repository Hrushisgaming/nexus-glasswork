#!/usr/bin/env python3
"""Generate Glasswork's "Blocky" TripleOscillator presets (Roblox-OST style) from the stock preset template.
Run from the repo root:  python3 tools/gen_presets.py
Envelope knob values are positions, not seconds: seconds = value^2 * 5 (att/hold/dec/rel).
"""
import xml.etree.ElementTree as ET

TPL = 'data/presets/TripleOscillator/AmazingBubbles.xpf'
OUT = 'data/presets/TripleOscillator/'
W = dict(sine=0, tri=1, saw=2, square=3, moog=4, exp=5, noise=6)
F = dict(lp=0, hp=1, bp=2, moog=6, dlp=7, formant=14)

def osc(wave, coarse=0, vol=33, fine=0, stph=0, pan=0, ph=0):
    return dict(wave=W[wave], coarse=coarse, vol=vol, fine=fine, stph=stph, pan=pan, ph=ph)

def filt(t, cut, res=0.5, env=0.0, edec=0.3, eatt=0.0, esus=0.0):
    return dict(t=t, cut=cut, res=res, env=env, edec=edec, eatt=eatt, esus=esus)

def env(att=0.0, dec=0.3, sus=0.0, rel=0.2): return dict(att=att, dec=dec, sus=sus, rel=rel)

def p(oscs, vol, filt=None, mod=(2, 2)): return dict(oscs=oscs, vol=vol, filt=filt, mod=mod)

PRESETS = {
 # ---- melodic / leads / pads / keys
 "Blocky Bright Pluck": p([osc('saw',0,40,-6,40), osc('square',0,30,6,90), osc('sine',12,28)], env(0,.42,0,.22), filt('moog',900,1.0,.55,.3)),
 "Blocky Glass Bell": p([osc('sine',0,60), osc('sine',19,34,4), osc('tri',12,26)], env(0,.55,0,.45), None, (4,2)),
 "Blocky Music Box": p([osc('sine',12,55), osc('tri',19,30), osc('sine',24,14)], env(0,.38,0,.35), None),
 "Blocky Marimba": p([osc('sine',0,70), osc('sine',24,22), osc('noise',0,5)], env(0,.27,0,.18), filt('lp',5200,.4)),
 "Blocky Chip Lead": p([osc('square',0,45), osc('square',12,20,5), osc('tri',-12,35)], env(0,.2,1,.1), None),
 "Blocky Supersaw Lead": p([osc('saw',0,33,-14,60), osc('saw',0,33,0,180), osc('saw',0,33,14,300)], env(.05,.3,1,.25), filt('lp',4200,.35)),
 "Blocky Warm Pad": p([osc('saw',0,30,-9,120), osc('tri',0,40,9,240), osc('saw',-12,26,0,30)], env(.55,.5,1,.62), filt('lp',1200,.5)),
 "Blocky Soft Keys": p([osc('sine',0,60), osc('sine',12,28), osc('tri',0,25,3)], env(0,.5,.12,.3), filt('lp',3800,.3,.25,.4), (4,2)),
 "Blocky Pizzicato Strings": p([osc('saw',0,36,-8,80), osc('saw',0,36,8,200), osc('square',12,16)], env(0,.3,0,.2), filt('lp',1900,.5,.35,.25)),
 "Blocky Distorted Lead": p([osc('saw',0,40,-5,70), osc('square',12,25,5,200), osc('saw',0,30,0,300)], env(.02,.3,1,.12), filt('lp',3000,.8), (3,2)),
 # ---- bass
 "Blocky 808 Sub": p([osc('sine',-24,80), osc('tri',-12,14), osc('sine',-12,10)], env(0,.55,.25,.25), filt('lp',600,.3)),
 "Blocky Reese Growl": p([osc('saw',-12,38,-12,60), osc('saw',-12,38,12,240), osc('saw',-24,30)], env(0,.4,1,.2), filt('moog',500,2.0,.4,.4)),
 "Blocky Slap Bass": p([osc('square',-12,40), osc('saw',-12,30,5), osc('sine',-24,40)], env(0,.3,.45,.12), filt('moog',350,1.2,.8,.15)),
 "Blocky Hellfire Bass": p([osc('saw',-12,45,-6), osc('square',-12,30,6), osc('saw',-24,35)], env(0,.3,1,.15), filt('dlp',900,2.5,.3,.3), (3,2)),
 "Blocky Rubber Bass": p([osc('tri',-12,50), osc('sine',-12,30), osc('square',-24,25)], env(0,.3,.6,.15), filt('lp',900,.5,.2,.3), (4,2)),
 "Blocky Bouncy Bass": p([osc('square',-12,40), osc('saw',-12,30,4), osc('sine',-24,45)], env(0,.38,.35,.15), filt('moog',320,1.4,.7,.22)),
 "Blocky Chip Bass": p([osc('square',-12,50), osc('tri',-24,50), osc('sine',-24,0)], env(0,.25,.5,.1), None),
 # ---- cymbals / hats / percussion (noise + inharmonic squares, high-passed)
 "Blocky Closed Hat": p([osc('noise',0,45), osc('square',24,12), osc('square',19,10)], env(0,.13,0,.08), filt('hp',7500,.3)),
 "Blocky Open Hat": p([osc('noise',0,45), osc('square',24,12), osc('square',19,10)], env(0,.32,0,.2), filt('hp',6500,.3)),
 "Blocky Crash Cymbal": p([osc('noise',0,55), osc('square',24,25,3), osc('square',19,20,-3)], env(.02,.72,0,.6), filt('hp',5000,.4)),
 "Blocky Ride Cymbal": p([osc('noise',0,20), osc('square',24,40,3), osc('square',17,40,-3)], env(0,.55,0,.4), filt('hp',4500,.5)),
 "Blocky Splash Cymbal": p([osc('noise',0,55), osc('square',24,22,4), osc('square',19,18,-4)], env(0,.4,0,.3), filt('hp',6000,.4)),
 "Blocky Snappy Snare": p([osc('noise',0,60), osc('tri',7,45), osc('sine',-5,25)], env(0,.17,0,.1), filt('hp',1200,.5)),
 "Blocky Clap": p([osc('noise',0,70), osc('noise',0,20), osc('sine',0,0)], env(0,.15,0,.12), filt('bp',1600,1.0)),
 "Blocky Tom": p([osc('tri',-12,70), osc('sine',-12,30), osc('noise',0,6)], env(0,.25,0,.2), filt('lp',2200,.4)),
 # ---- cinematic / chase-theme / FX
 "Blocky Brass Stab": p([osc('saw',0,35), osc('saw',12,25,6), osc('square',0,25,-6)], env(0,.3,.6,.15), filt('moog',800,.8,.7,.15)),
 "Blocky Orchestra Hit": p([osc('saw',0,35), osc('saw',7,30), osc('saw',12,30)], env(0,.35,0,.3), filt('lp',2500,.4)),
 "Blocky Choir Pad": p([osc('tri',0,40), osc('saw',0,30,8,120), osc('saw',12,22,-8,240)], env(.45,.5,1,.6), filt('formant',800,.6)),
 "Blocky Dark Drone": p([osc('saw',-24,40), osc('saw',-12,30,10,90), osc('square',-24,25,-8,200)], env(.7,.5,1,.8), filt('lp',350,.6)),
 "Blocky Impact Boom": p([osc('sine',-24,60), osc('noise',0,40), osc('tri',-12,30)], env(0,.7,0,.6), filt('lp',300,.5)),
 "Blocky Riser": p([osc('noise',0,60), osc('saw',0,25,6,100), osc('saw',12,15,-6,200)], env(.6,.1,1,.4), filt('lp',400,1.2,.9,.01,.8,1.0)),
}

def build(name, d):
    tree = ET.parse(TPL); root = tree.getroot()
    its = root.find('instrumenttracksettings'); its.set('name', name)
    it = its.find('instrumenttrack'); it.set('vol', '100'); it.set('basenote', '57')
    to = it.find('instrument/tripleoscillator')
    for i, o in enumerate(d['oscs']):
        for k, v in {f'vol{i}': o['vol'], f'pan{i}': o['pan'], f'coarse{i}': o['coarse'], f'finel{i}': o['fine'],
                     f'finer{i}': o['fine'], f'phoffset{i}': o['ph'], f'stphdetun{i}': o['stph'],
                     f'wavetype{i}': o['wave'], f'userwavefile{i}': 'samples/empty.wav'}.items():
            to.set(k, str(v))
    to.set('modalgo1', str(d['mod'][0])); to.set('modalgo2', str(d['mod'][1])); to.set('modalgo3', '2')
    el = it.find('eldata'); ev = el.find('elvol'); ec = el.find('elcut'); v = d['vol']
    for k, val in dict(att=v['att'], dec=v['dec'], sustain=v['sus'], rel=v['rel'], amt=1, hold=0).items(): ev.set(k, str(val))
    f = d['filt']
    if f:
        for k, val in dict(fwet=1, ftype=F[f['t']], fcut=f['cut'], fres=f['res']).items(): el.set(k, str(val))
        for k, val in dict(amt=f['env'], att=f['eatt'], hold=0, dec=f['edec'], sustain=f['esus'], rel=0).items(): ec.set(k, str(val))
    else:
        for k, val in dict(fwet=0, ftype=0, fcut=14000, fres=0.5).items(): el.set(k, str(val))
        ec.set('amt', '0')
    fn = OUT + name.replace(' ', '') + '.xpf'
    ET.indent(tree); tree.write(fn, encoding='utf-8', xml_declaration=True)
    s = open(fn).read().replace("<?xml version='1.0' encoding='utf-8'?>", '<?xml version="1.0"?>\n<!DOCTYPE lmms-project>', 1)
    open(fn, 'w').write(s)
    return fn

def validate(fn):
    r = ET.parse(fn).getroot(); t = r.find('.//tripleoscillator'); e = r.find('.//eldata')
    for i in range(3):
        assert -24 <= int(t.get(f'coarse{i}')) <= 24, (fn, 'coarse', i)
        assert 0 <= int(t.get(f'vol{i}')) <= 200, (fn, 'vol', i)
        assert -100 <= int(t.get(f'finel{i}')) <= 100, (fn, 'fine', i)
        assert 0 <= int(t.get(f'wavetype{i}')) <= 6, (fn, 'wave', i)
    assert 0 <= float(e.get('fcut')) <= 14000 and 0 <= float(e.get('fres')) <= 10, (fn, 'filter')

if __name__ == '__main__':
    made = [build(n, d) for n, d in PRESETS.items()]
    for fn in made: validate(fn)
    print(len(made), 'presets written and validated')
