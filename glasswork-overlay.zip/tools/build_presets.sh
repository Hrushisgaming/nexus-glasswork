#!/usr/bin/env bash
# Regenerate every Glasswork preset and starter project, in the right order. Run from the repo root.
set -euo pipefail
python3 tools/gen_presets.py
python3 tools/gen_fm_acid_presets.py
python3 tools/gen_glasswork_presets.py
python3 tools/add_effects.py
python3 tools/make_starter_project.py
python3 tools/make_genre_projects.py
