#!/usr/bin/env python3
"""Build data/projects/templates/GlassworkStarter.mpt: an FL-style starter with a drum rack (step sequencer),
bass / lead / pad / keys tracks, and one mixer insert per group. Run after the preset generators, from the repo root."""
import copy, xml.etree.ElementTree as ET

BASE = 'data/projects/templates/TR808.mpt'      # reuse its scaffolding (head, mixer, subwindow elements)
OUT  = 'data/projects/templates/GlassworkStarter.mpt'
P = 'data/presets/'

def preset_track(path):
    r = ET.parse(path).getroot()
    return copy.deepcopy(r.find('.//instrumenttrack')), r.find('.//instrumenttracksettings').get('name')

def make_track(name, preset, mixch):
    it, _ = preset_track(preset)
    it.set('mixch', str(mixch)); it.set('usemasterpitch', '1')
    t = ET.Element('track', dict(type='0', muted='0', name=name, solo='0'))
    t.append(it); return t, it

def step_pattern(track, name, steps):
    p = ET.SubElement(track, 'pattern', dict(type='0', muted='0', steps='16', name=name, pos='0', len='192'))
    for s in sorted(steps):
        ET.SubElement(p, 'note', dict(key='57', pan='0', len='12', vol='100', pos=str(s * 12)))

tree = ET.parse(BASE); root = tree.getroot()
head = root.find('head'); head.set('bpm', '128')
song = root.find('song'); songtc = song.find('trackcontainer')
for t in list(songtc): songtc.remove(t)
songtc.set('x', '565'); songtc.set('y', '0'); songtc.set('width', '720'); songtc.set('height', '420')

# mixer: Master + one insert per group, all sending to master
mixer = song.find('mixer'); mixer.set('x', '0'); mixer.set('y', '425'); mixer.set('width', '720'); mixer.set('height', '320')
for ch in mixer.findall('mixerchannel'):
    if ch.get('num') != '0': mixer.remove(ch)
GROUPS = ['Drums', 'Bass', 'Lead', 'Pad', 'Keys']
for i, g in enumerate(GROUPS, start=1):
    ch = ET.SubElement(mixer, 'mixerchannel', dict(num=str(i), muted='0', volume='0.8' if g != 'Drums' else '0.9', name=g, soloed='0'))
    ET.SubElement(ch, 'fxchain', dict(numofeffects='0', enabled='0'))
    ET.SubElement(ch, 'send', dict(amount='1', channel='0'))

# melodic tracks in the song editor (empty clips; the sounds are loaded and routed)
melodic = [('Bass: 808 Sub', P + 'TripleOscillator/Blocky808Sub.xpf', 2), ('Lead: Supersaw', P + 'TripleOscillator/BlockySupersawLead.xpf', 3),
           ('Pad: Warm', P + 'TripleOscillator/BlockyWarmPad.xpf', 4), ('Keys: Soft', P + 'TripleOscillator/BlockySoftKeys.xpf', 5)]
for name, preset, mix in melodic:
    t, _ = make_track(name, preset, mix); songtc.append(t)

# drum rack: the Pattern track holds one instrument per drum with a 16-step pattern
drums = [  # name, preset, steps (0-15)
 ('Kick',        P + 'Kicker/KickPower.xpf',                       [0, 4, 8, 12]),
 ('Snare',       P + 'TripleOscillator/BlockySnappySnare.xpf',     [4, 12]),
 ('Clap',        P + 'TripleOscillator/BlockyClap.xpf',            [4, 12]),
 ('Closed Hat',  P + 'TripleOscillator/BlockyClosedHat.xpf',       [0, 2, 4, 6, 8, 10, 12, 14]),
 ('Open Hat',    P + 'TripleOscillator/BlockyOpenHat.xpf',         [14]),
 ('Crash',       P + 'TripleOscillator/BlockyCrashCymbal.xpf',     [0]),
 ('Tom',         P + 'TripleOscillator/BlockyTom.xpf',             []),
]
bbtrack_el = ET.Element('track', dict(type='1', muted='0', name='Beat 1', solo='0'))
bb = ET.SubElement(bbtrack_el, 'bbtrack')
bbtc = ET.SubElement(bb, 'trackcontainer', dict(visible='1', width='560', height='420', type='bbtrackcontainer', x='0', y='0', maximized='0', minimized='0'))
for name, preset, steps in drums:
    t, _ = make_track(name, preset, 1); step_pattern(t, name, steps); bbtc.append(t)
for pos in (0, 192, 384, 576):                # play the beat for 4 bars
    ET.SubElement(bbtrack_el, 'bbtco', dict(pos=str(pos), len='192', muted='0', name=''))
songtc.append(bbtrack_el)

# hide the editors that are not needed on first open
for tag in ('pianoroll', 'automationeditor', 'projectnotes'): 
    e = song.find(tag)
    if e is not None: e.set('visible', '0')

ET.indent(tree); tree.write(OUT, encoding='utf-8', xml_declaration=True)
s = open(OUT).read().replace("<?xml version='1.0' encoding='utf-8'?>", '<?xml version="1.0"?>\n<!DOCTYPE lmms-project>', 1)
open(OUT, 'w').write(s)

# self-check
r = ET.parse(OUT).getroot()
tracks = r.findall('./song/trackcontainer/track')
inner = r.findall('.//bbtrack/trackcontainer/track')
assert len(tracks) == 5 and len(inner) == len(drums)
assert all(t.find('instrumenttrack/instrument') is not None for t in tracks[:4] + inner)
assert len(r.findall('.//mixerchannel')) == 6
print('starter written:', len(tracks), 'song tracks (incl. beat), ', len(inner), 'drum instruments,',
      sum(len(p.findall('note')) for p in r.iter('pattern')), 'step notes,', len(r.findall('.//bbtco')), 'pattern clips')
