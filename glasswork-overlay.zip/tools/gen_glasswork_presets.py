#!/usr/bin/env python3
"""Presets for Glasswork's own instruments (Saw, Pluck, Metal, Bass). Effects are added afterwards by add_effects.py.
Run from the repo root.  Envelope knob values are positions: seconds = value^2 * 5."""
import copy, os, xml.etree.ElementTree as ET

BASE = 'data/presets/TripleOscillator/BlockySupersawLead.xpf'   # supplies track + envelope/filter scaffolding

def env(att=0.0, dec=0.3, sus=1.0, rel=0.2): return dict(att=att, dec=dec, sus=sus, rel=rel)

PRESETS = {
 'GlassworkSaw': ('glassworksaw', {
   'GW Supersaw Lead':  (dict(voices=7, detune=22, spread=0.85, shape=0.0, sub=0.0, drive=0.15, gain=1.0), env(0.02, 0.3, 1.0, 0.25)),
   'GW Trance Pluck':   (dict(voices=5, detune=12, spread=0.7, shape=0.3, sub=0.0, drive=0.3, gain=1.0),  env(0.0, 0.28, 0.0, 0.2)),
   'GW Wide Pad':       (dict(voices=9, detune=30, spread=1.0, shape=0.0, sub=0.2, drive=0.0, gain=0.9),  env(0.5, 0.5, 1.0, 0.6)),
   'GW Hoover':         (dict(voices=9, detune=45, spread=0.9, shape=0.5, sub=0.0, drive=0.5, gain=0.9),  env(0.03, 0.4, 1.0, 0.3)),
   'GW Pump Pad':       (dict(voices=7, detune=26, spread=1.0, shape=0.1, sub=0.3, drive=0.1, gain=0.9),  env(0.2, 0.5, 1.0, 0.4)),
 }),
 'GlassworkPluck': ('glassworkpluck', {
   'GW Harp':           (dict(decay=0.75, damping=0.3, bright=0.5, pick=0.15, gain=1.0), env(0.0, 0.7, 1.0, 0.3)),
   'GW Nylon Guitar':   (dict(decay=0.6, damping=0.5, bright=0.35, pick=0.2, gain=1.0),  env(0.0, 0.7, 1.0, 0.25)),
   'GW Bright Pluck':   (dict(decay=0.5, damping=0.2, bright=0.9, pick=0.05, gain=1.0),  env(0.0, 0.7, 1.0, 0.2)),
   'GW Muted Pluck':    (dict(decay=0.25, damping=0.6, bright=0.5, pick=0.1, gain=1.0),  env(0.0, 0.5, 1.0, 0.1)),
   'GW String Bass':    (dict(decay=0.55, damping=0.55, bright=0.3, pick=0.1, gain=1.2),  env(0.0, 0.7, 1.0, 0.2)),
 }),
 'GlassworkMetal': ('glassworkmetal', {
   'GW Closed Hat':     (dict(tune=1.0, metal=0.7, noise=0.5, tone=7500, body=0.15, decay=70,   tail=0.0,  keytrack=0, gain=1.0), env(0, 0.3, 1.0, 0.1)),
   'GW Open Hat':       (dict(tune=1.0, metal=0.7, noise=0.5, tone=7000, body=0.15, decay=350,  tail=0.1,  keytrack=0, gain=1.0), env(0, 0.3, 1.0, 0.1)),
   'GW Crash':          (dict(tune=1.0, metal=0.8, noise=0.5, tone=4500, body=0.3,  decay=2200, tail=0.45, keytrack=0, gain=1.0), env(0, 0.3, 1.0, 0.1)),
   'GW Ride':           (dict(tune=1.0, metal=1.0, noise=0.15, tone=5500, body=0.4, decay=1400, tail=0.3,  keytrack=0, gain=1.0), env(0, 0.3, 1.0, 0.1)),
   'GW Splash':         (dict(tune=1.1, metal=0.8, noise=0.5, tone=6000, body=0.25, decay=800,  tail=0.2,  keytrack=0, gain=1.0), env(0, 0.3, 1.0, 0.1)),
   'GW Cowbell':        (dict(tune=1.3, metal=0.9, noise=0.0, tone=2500, body=0.7,  decay=500,  tail=0.0,  keytrack=0, gain=1.0), env(0, 0.3, 1.0, 0.1)),
   'GW Shaker':         (dict(tune=1.0, metal=0.1, noise=0.9, tone=5000, body=0.0,  decay=90,   tail=0.0,  keytrack=0, gain=1.0), env(0, 0.3, 1.0, 0.1)),
 }),
 'GlassworkBass': ('glassworkbass', {
   'GW Reese':          (dict(saw=0.6, square=0.3, sub=0.5, cutoff=350, res=0.45, envamt=0.5,  envdecay=600, drive=0.35, gain=1.0), env(0, 0.4, 1.0, 0.2)),
   'GW Sub Pump':       (dict(saw=0.15, square=0.0, sub=1.0, cutoff=200, res=0.1, envamt=0.2, envdecay=300, drive=0.1,  gain=1.0), env(0, 0.4, 1.0, 0.2)),
   'GW Slap Funk':      (dict(saw=0.5, square=0.5, sub=0.4, cutoff=500, res=0.5,  envamt=0.85, envdecay=120, drive=0.25, gain=1.0), env(0, 0.35, 0.5, 0.12)),
   'GW Acid Squelch':   (dict(saw=0.9, square=0.0, sub=0.2, cutoff=250, res=0.75, envamt=0.9,  envdecay=180, drive=0.4,  gain=1.0), env(0, 0.3, 0.7, 0.12)),
   'GW Hellfire':       (dict(saw=0.6, square=0.6, sub=0.5, cutoff=600, res=0.6,  envamt=0.5,  envdecay=300, drive=0.8,  gain=0.9), env(0, 0.4, 1.0, 0.15)),
   'GW Rubber':         (dict(saw=0.3, square=0.5, sub=0.6, cutoff=700, res=0.3,  envamt=0.4,  envdecay=250, drive=0.2,  gain=1.0), env(0, 0.4, 0.6, 0.15)),
 }),
}

made = 0
for folder, (plugin, presets) in PRESETS.items():
    os.makedirs('data/presets/' + folder, exist_ok=True)
    for name, (params, e) in presets.items():
        tree = ET.parse(BASE); root = tree.getroot()
        its = root.find('instrumenttracksettings'); its.set('name', name)
        it = its.find('instrumenttrack'); it.set('basenote', '57'); it.set('vol', '100')
        inst = it.find('instrument'); inst.set('name', plugin)
        for child in list(inst): inst.remove(child)
        ET.SubElement(inst, plugin, {k: str(v) for k, v in params.items()})
        el = it.find('eldata'); ev = el.find('elvol'); ec = el.find('elcut')
        for k, v in dict(att=e['att'], dec=e['dec'], sustain=e['sus'], rel=e['rel'], amt=1, hold=0).items(): ev.set(k, str(v))
        el.set('fwet', '0'); el.set('ftype', '0'); el.set('fcut', '14000'); el.set('fres', '0.5'); ec.set('amt', '0')
        fx = it.find('fxchain')
        if fx is not None:
            for x in list(fx): fx.remove(x)
            fx.set('numofeffects', '0')
        path = 'data/presets/%s/%s.xpf' % (folder, name.replace(' ', ''))
        ET.indent(tree); tree.write(path, encoding='utf-8', xml_declaration=True)
        s = open(path).read().replace("<?xml version='1.0' encoding='utf-8'?>", '<?xml version="1.0"?>\n<!DOCTYPE lmms-project>', 1)
        open(path, 'w').write(s); made += 1
print(made, 'Glasswork-instrument presets written')
