#!/usr/bin/env python3
"""Glasswork presets for the engines closest to FL Studio's Sytrus/DX10 (OpulenZ FM) and Transistor Bass (LB302).
Each preset starts from a stock LMMS preset and changes a handful of parameters. Run from the repo root."""
import xml.etree.ElementTree as ET

def load(path):
    t = ET.parse(path); return t, t.getroot()

def strip_fx(root):
    for fx in root.iter('fxchain'):
        for e in list(fx): fx.remove(e)
        fx.set('numofeffects', '0')

def save(tree, root, path, name, doctype):
    root.find('instrumenttracksettings').set('name', name)
    strip_fx(root)
    ET.indent(tree); tree.write(path, encoding='utf-8', xml_declaration=True)
    s = open(path).read().replace("<?xml version='1.0' encoding='utf-8'?>", '<?xml version="1.0"?>\n<!DOCTYPE %s>' % doctype, 1)
    open(path, 'w').write(s)

# ---- OpulenZ (2-operator FM): base preset + changed attributes
OPL = 'data/presets/OpulenZ/'
OPL_VARIANTS = {
 'Blocky FM Glock':      ('Bells',      dict(op1_lvl=36, op1_mul=8, op2_d=11, op2_r=13)),
 'Blocky FM Tines':      ('Epiano',     dict(op1_lvl=44, feedback=1, op2_d=13)),
 'Blocky FM Brass Hit':  ('Brass',      dict(op1_a=10, op2_a=10, op2_d=2, op1_lvl=50, feedback=5)),
 'Blocky FM Vibes':      ('Vibraphone', dict(op1_lvl=26, op2_r=10, op1_r=10)),
 'Blocky FM Slap Bass':  ('Funky',      dict(op1_lvl=56, op2_d=14, op2_s=8)),
}
for name, (base, ch) in OPL_VARIANTS.items():
    t, r = load(OPL + base + '.xpf'); o = r.find('.//OPL2')
    for k, v in ch.items(): o.set(k, str(v))
    for k in ('op1_lvl','op2_lvl'): assert 0 <= int(o.get(k)) <= 63
    for k in ('op1_a','op1_d','op1_s','op1_r','op2_a','op2_d','op2_s','op2_r','feedback'): assert 0 <= int(o.get(k)) <= 15
    save(t, r, OPL + name.replace(' ', '') + '.xpf', name, 'multimedia-project')

# ---- LB302 (TB-303-style bass synth), the nearest thing to Transistor Bass
LB = 'data/presets/LB302/'
LB_VARIANTS = {
 'Blocky Acid Bass':    dict(shape=0, vcf_cut=0.12, vcf_res=1.1,  vcf_mod=0.55, vcf_dec=0.2,  dist=0.3, slide=1, slide_dec=0.35, dead=0, db24=0),
 'Blocky Sub 303':      dict(shape=5, vcf_cut=0.5,  vcf_res=0.1,  vcf_mod=0.1,  vcf_dec=0.3,  dist=0,   slide=0, slide_dec=0.5,  dead=0, db24=0),
 'Blocky Squelch Lead': dict(shape=2, vcf_cut=0.3,  vcf_res=1.2,  vcf_mod=0.7,  vcf_dec=0.3,  dist=0.1, slide=1, slide_dec=0.4,  dead=0, db24=1),
 'Blocky Rubber Slide': dict(shape=3, vcf_cut=0.25, vcf_res=0.6,  vcf_mod=0.4,  vcf_dec=0.25, dist=0,   slide=1, slide_dec=0.6,  dead=0, db24=0),
}
for name, ch in LB_VARIANTS.items():
    t, r = load(LB + 'AcidLead.xpf'); l = r.find('.//lb302')
    for k, v in ch.items(): l.set(k, str(v))
    r.find('.//instrumenttrack').set('basenote', '45'); r.find('.//instrumenttrack').set('vol', '80')
    save(t, r, LB + name.replace(' ', '') + '.xpf', name, 'lmms-project')
print(len(OPL_VARIANTS), 'OpulenZ and', len(LB_VARIANTS), 'LB302 presets written and range-checked')
