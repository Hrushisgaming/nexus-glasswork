#!/usr/bin/env python3
"""Build three genre starter projects (File > New from template): Horror Chase, Chiptune Obby, Funky Lobby.
Each has a drum rack (step sequencer), written bass/lead/pad parts, and one mixer insert per group.
Run after the preset generators, from the repo root."""
import copy, xml.etree.ElementTree as ET

BASE = 'data/projects/templates/TR808.mpt'
P = 'data/presets/'
PRESET = dict(
  kick=P+'Kicker/KickPower.xpf', snare=P+'TripleOscillator/BlockySnappySnare.xpf', clap=P+'TripleOscillator/BlockyClap.xpf',
  chat=P+'GlassworkMetal/GWClosedHat.xpf', ohat=P+'GlassworkMetal/GWOpenHat.xpf', tom=P+'TripleOscillator/BlockyTom.xpf',
  crash=P+'GlassworkMetal/GWCrash.xpf', riser=P+'TripleOscillator/BlockyRiser.xpf',
  hellfire=P+'GlassworkBass/GWHellfire.xpf', distlead=P+'TripleOscillator/BlockyDistortedLead.xpf', saw=P+'GlassworkSaw/GWSupersawLead.xpf',
  drone=P+'TripleOscillator/BlockyDarkDrone.xpf', choir=P+'TripleOscillator/BlockyChoirPad.xpf', orch=P+'TripleOscillator/BlockyOrchestraHit.xpf',
  chipbass=P+'TripleOscillator/BlockyChipBass.xpf', chiplead=P+'TripleOscillator/BlockyChipLead.xpf', musicbox=P+'TripleOscillator/BlockyMusicBox.xpf',
  slap=P+'GlassworkBass/GWSlapFunk.xpf', keys=P+'TripleOscillator/BlockySoftKeys.xpf', brass=P+'TripleOscillator/BlockyBrassStab.xpf',
  pluck=P+'GlassworkPluck/GWBrightPluck.xpf',
)
K = lambda midi: midi - 12            # LMMS key numbers are MIDI note - 12 (key 57 = A4)

def instrument_track(name, preset, mixch):
    r = ET.parse(preset).getroot(); it = copy.deepcopy(r.find('.//instrumenttrack'))
    it.set('mixch', str(mixch)); it.set('usemasterpitch', '1')
    t = ET.Element('track', dict(type='0', muted='0', name=name, solo='0')); t.append(it); return t

def add_steps(track, name, steps):
    p = ET.SubElement(track, 'pattern', dict(type='0', muted='0', steps='16', name=name, pos='0', len='192'))
    for s in sorted(steps): ET.SubElement(p, 'note', dict(key='57', pan='0', len='12', vol='100', pos=str(s * 12)))

def add_clip(track, start_bar, bars, notes):
    """notes: (midi, step16 within the clip, length in 16ths, volume)"""
    p = ET.SubElement(track, 'pattern', dict(type='1', muted='0', steps='16', name='', pos=str(start_bar * 192), len=str(bars * 192)))
    for midi, step, ln, vol in notes:
        ET.SubElement(p, 'note', dict(key=str(K(midi)), pan='0', len=str(ln * 12), vol=str(vol), pos=str(step * 12)))

def build(out, bpm, groups, drums, parts, beat_bars):
    tree = ET.parse(BASE); root = tree.getroot(); root.find('head').set('bpm', str(bpm))
    song = root.find('song'); tc = song.find('trackcontainer')
    for t in list(tc): tc.remove(t)
    tc.set('x', '565'); tc.set('y', '0'); tc.set('width', '720'); tc.set('height', '420')
    mixer = song.find('mixer'); mixer.set('x', '0'); mixer.set('y', '425'); mixer.set('width', '720'); mixer.set('height', '320')
    for ch in mixer.findall('mixerchannel'):
        if ch.get('num') != '0': mixer.remove(ch)
    for i, g in enumerate(groups, start=1):
        ch = ET.SubElement(mixer, 'mixerchannel', dict(num=str(i), muted='0', volume='0.85', name=g, soloed='0'))
        ET.SubElement(ch, 'fxchain', dict(numofeffects='0', enabled='0')); ET.SubElement(ch, 'send', dict(amount='1', channel='0'))
    for name, key, mix, clips in parts:
        t = instrument_track(name, PRESET[key], mix)
        for start, bars, notes in clips: add_clip(t, start, bars, notes)
        tc.append(t)
    beat = ET.Element('track', dict(type='1', muted='0', name='Beat', solo='0'))
    bb = ET.SubElement(beat, 'bbtrack')
    bbtc = ET.SubElement(bb, 'trackcontainer', dict(visible='1', width='560', height='420', type='bbtrackcontainer', x='0', y='0', maximized='0', minimized='0'))
    for name, key, steps in drums:
        t = instrument_track(name, PRESET[key], 1); add_steps(t, name, steps); bbtc.append(t)
    for b in range(beat_bars): ET.SubElement(beat, 'bbtco', dict(pos=str(b * 192), len='192', muted='0', name=''))
    tc.append(beat)
    for tag in ('pianoroll', 'automationeditor', 'projectnotes'):
        e = song.find(tag)
        if e is not None: e.set('visible', '0')
    ET.indent(tree); tree.write(out, encoding='utf-8', xml_declaration=True)
    s = open(out).read().replace("<?xml version='1.0' encoding='utf-8'?>", '<?xml version="1.0"?>\n<!DOCTYPE lmms-project>', 1)
    open(out, 'w').write(s)
    r = ET.parse(out).getroot()
    nn = sum(len(p.findall('note')) for p in r.iter('pattern'))
    print(out.split('/')[-1], '-', len(r.findall('./song/trackcontainer/track')), 'song tracks,', len(r.findall('.//bbtrack/trackcontainer/track')), 'drums,', nn, 'notes')

def arp(chord, bars, offset=0):          # one 16th-note arpeggio per bar
    return [(chord[i % len(chord)], i, 1, 90) for i in range(16)]

# ---------------------------------------------------------------- 1. Horror Chase (A minor, 150 BPM, 8 bars)
roots = [33, 33, 29, 28, 33, 33, 29, 28]                 # A A F E, twice
bass = [(r + (12 if s in (6, 11) else 0), s, 1, 100) for r in [0] for s in []]  # placeholder (built per bar below)
bass_clips = []
for bar, r in enumerate(roots):
    bass_clips.append((bar, 1, [(r + (12 if s in (6, 11) else 0), s, 1, 100) for s in (0, 2, 3, 6, 8, 10, 11, 14)]))
lead_motif = [[(69,0,3,100),(72,4,2,100),(71,6,2,100),(69,8,4,100),(64,12,4,95)],
              [(69,0,3,100),(72,4,2,100),(76,6,2,100),(74,8,4,100),(72,12,4,95)],
              [(65,0,3,100),(69,4,2,100),(72,6,2,100),(69,8,4,100),(65,12,4,95)],
              [(64,0,4,100),(68,4,4,100),(71,8,4,100),(76,12,4,105)]]
lead_clips = [(b, 1, lead_motif[b % 4]) for b in range(8)]
chords = {33: [45, 52, 57, 60], 29: [41, 48, 53, 57], 28: [40, 47, 52, 56]}
pad_clips = [(b, 1, [(n, 0, 16, 85) for n in chords[r]]) for b, r in enumerate(roots)]
hits = [(b, 1, [(n, 0, 2, 110) for n in (57, 60, 64)]) for b in (0, 2, 4, 6)]
build('data/projects/templates/GlassworkHorrorChase.mpt', 150, ['Drums', 'Bass', 'Lead', 'Pad', 'FX'],
  [('Kick', 'kick', [0, 6, 8, 11]), ('Snare', 'snare', [4, 12]), ('Clap', 'clap', [12]), ('Closed Hat', 'chat', list(range(0, 16, 2))),
   ('Open Hat', 'ohat', [14]), ('Tom', 'tom', [10, 15])],
  [('Bass: Hellfire', 'hellfire', 2, bass_clips), ('Lead: Distorted', 'distlead', 3, lead_clips), ('Pad: Dark Drone', 'drone', 4, pad_clips),
   ('Hits: Orchestra', 'orch', 5, hits), ('Crash', 'crash', 5, [(0, 1, [(57, 0, 16, 100)]), (4, 1, [(57, 0, 16, 100)])]),
   ('Riser', 'riser', 5, [(3, 1, [(57, 0, 16, 100)]), (7, 1, [(57, 0, 16, 100)])])], 8)

# ---------------------------------------------------------------- 2. Chiptune Obby (C major, 140 BPM, 8 bars)
croots = [36, 33, 29, 31, 36, 33, 29, 31]                # C Am F G, twice
cbass = [(b, 1, [(r + (12 if s % 4 == 2 else 0), s, 1, 100) for s in range(0, 16, 2)]) for b, r in enumerate(croots)]
melody = [[(76,0,2,100),(79,2,2,100),(84,4,4,100),(83,8,2,100),(79,10,2,100),(76,12,4,100)],
          [(81,0,2,100),(79,2,2,100),(76,4,4,100),(72,8,4,100),(76,12,4,100)],
          [(77,0,2,100),(81,2,2,100),(84,4,4,100),(81,8,2,100),(77,10,2,100),(72,12,4,100)],
          [(79,0,2,100),(83,2,2,100),(86,4,4,100),(83,8,4,100),(79,12,4,105)]]
cchords = {36: [60, 64, 67, 72], 33: [57, 60, 64, 69], 29: [53, 57, 60, 65], 31: [55, 59, 62, 67]}
carp = [(b, 1, arp(cchords[r], 1)) for b, r in enumerate(croots)]
build('data/projects/templates/GlassworkChiptuneObby.mpt', 140, ['Drums', 'Bass', 'Lead', 'Arp'],
  [('Kick', 'kick', [0, 8]), ('Snare', 'snare', [4, 12]), ('Closed Hat', 'chat', [2, 6, 10, 14]), ('Open Hat', 'ohat', [14]), ('Clap', 'clap', [12])],
  [('Bass: Chip', 'chipbass', 2, cbass), ('Lead: Chip', 'chiplead', 3, [(b, 1, melody[b % 4]) for b in range(8)]),
   ('Arp: Music Box', 'musicbox', 4, carp), ('Crash', 'crash', 1, [(0, 1, [(57, 0, 16, 90)]), (4, 1, [(57, 0, 16, 90)])])], 8)

# ---------------------------------------------------------------- 3. Funky Lobby (Dm7 G7 Cmaj7 Cmaj7, 112 BPM, 8 bars)
froots = [38, 43, 36, 36, 38, 43, 36, 36]
fbass = [(b, 1, [(r, 0, 2, 100), (r, 3, 1, 90), (r + 12, 6, 1, 95), (r, 8, 2, 100), (r + 12, 10, 1, 95), (r, 12, 1, 90), (r + 7, 14, 1, 95)]) for b, r in enumerate(froots)]
fvoice = {38: [65, 69, 72, 74], 43: [65, 67, 71, 74], 36: [64, 67, 71, 74]}
fkeys = [(b, 1, [(n, s, ln, 85) for s, ln in ((2, 1), (5, 1), (10, 1), (13, 2)) for n in fvoice[r]]) for b, r in enumerate(froots)]
fbrass = [(b, 1, [(n, 4, 2, 105) for n in fvoice[r][:3]] + [(n, 12, 1, 100) for n in fvoice[r][:3]]) for b, r in enumerate(froots) if b % 2 == 1]
fpluck = [(b, 1, [(76, 0, 2, 95), (74, 3, 1, 90), (72, 6, 2, 95), (69, 10, 2, 95), (72, 13, 2, 100)]) for b in range(0, 8, 2)]
build('data/projects/templates/GlassworkFunkyLobby.mpt', 112, ['Drums', 'Bass', 'Keys', 'Brass', 'Lead'],
  [('Kick', 'kick', [0, 6, 10]), ('Snare', 'snare', [4, 12]), ('Clap', 'clap', [12]), ('Closed Hat', 'chat', list(range(0, 16, 2))), ('Open Hat', 'ohat', [14])],
  [('Bass: Slap Funk', 'slap', 2, fbass), ('Keys: Soft', 'keys', 3, fkeys), ('Brass: Stabs', 'brass', 4, fbrass),
   ('Lead: Pluck', 'pluck', 5, fpluck), ('Crash', 'crash', 1, [(0, 1, [(57, 0, 16, 90)]), (4, 1, [(57, 0, 16, 90)])])], 8)
