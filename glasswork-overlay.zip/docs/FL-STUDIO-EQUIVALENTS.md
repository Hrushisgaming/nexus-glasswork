# Glasswork vs. FL Studio instruments

FL Studio's own instruments are closed source, so none can be copied. This table lists, for each one, what Glasswork
(built on LMMS) has that does the same job. The instrument list comes from Image-Line's manual and their forum polls.

**Match** = same idea and similar control. **Close** = same job, different feature set.
**Approximate** = you can get the sound, but not with the same workflow. **Not covered** = nothing comparable yet.

| FL Studio | Glasswork | How close |
|---|---|---|
| 3x Osc, MiniSynth | Triple Oscillator (same 3-oscillator design, with FM/AM/sync modes) | Match |
| Sytrus (FM/RM/subtractive) | OpulenZ (2-operator FM) and Triple Oscillator FM mode; Dexed via Carla for DX7-style FM | Close |
| Harmor (additive, image synthesis) | ZynAddSubFX (additive "ADsynth"), Watsyn. No image or resynthesis engine | Close, partial |
| FLEX (preset-based synth) | The Blocky preset bank, ZynAddSubFX's banks, SoundFonts. Its large library cannot be copied | Approximate |
| Transistor Bass | LB302 (TB-303 style): Blocky Acid Bass, Sub 303, Squelch Lead, Rubber Slide | Close |
| Plucked!, Sakura | Vibed (string model) and the Mallets instrument (marimba, vibraphone, bells) | Close |
| BooBass (bass guitar) | No dedicated model. Use Blocky Slap, Rubber, Reese, 808 bass presets or a SoundFont bass | Approximate |
| FL Keys (piano and keys ROMpler) | Sf2Player with a free SoundFont (not bundled yet), plus Blocky Soft Keys and FM Tines | Approximate |
| FL Slayer (guitar) | No guitar model. Blocky Distorted Lead and Hellfire Bass, or a SoundFont guitar | Approximate |
| Fruity Kick, BassDrum | Kicker | Match |
| FPC, Drumpad, Drumaxx, DrumSynth Live | Beat editor (step sequencer) with Kicker, Blocky snare/hat/crash/ride/clap/tom presets, drum samples. No pad-grid UI | Close |
| Fruity Slicer, Slicex | SlicerT | Match |
| Channel Sampler, DirectWave, SoundFont Player | AudioFileProcessor, Sf2Player, GigPlayer | Close |
| DX10 | OpulenZ, Blocky FM presets | Close |
| Groove Machine Synth, Harmless, Sawer, PoiZone, Morphine, Ogun, Kepler | Triple Oscillator, Monstro, ZynAddSubFX. Blocky Supersaw Lead stands in for Sawer | Approximate |
| Patcher | Carla Patchbay / Rack | Close |
| Fruity Granulizer, Layer Channel | Nothing comparable (Granular Pitch Shifter is an effect, not a granular sampler) | Not covered |

## Using other plugins
Glasswork can host LV2 plugins and, through Carla, other formats such as AU, VST3 and CLAP on macOS. Popular free synths
(for example Vital, Surge XT, Dexed) can be loaded that way. Check that an Apple Silicon (arm64) build exists for each
before relying on it. None are bundled with Glasswork.

## Presets in this repo
- `tools/gen_presets.py` writes the Blocky TripleOscillator presets (leads, pads, keys, bass, cymbals, percussion, FX).
- `tools/gen_fm_acid_presets.py` writes the OpulenZ FM and LB302 acid-bass presets.
- `tools/add_effects.py` adds reverb, delay, bitcrush and compressor chains (38 presets) using LMMS's built-in effects.
- `tools/make_starter_project.py` builds the **Glasswork Starter** project (File > New from template): a 7-instrument drum rack with a
  step pattern, 808 bass, supersaw lead, pad and keys, each routed to its own mixer insert (Drums, Bass, Lead, Pad, Keys).
- `tools/build_presets.sh` runs all of the above in order.
- Every preset was range-checked but not listened to; treat them as starting points and adjust by ear.
