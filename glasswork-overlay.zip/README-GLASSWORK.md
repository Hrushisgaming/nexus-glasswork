# Nexus Glasswork

Glasswork is a personal fork of LMMS (GPL-2.0-or-later): a cleaner theme, a simple mode, one-click audio
recording, its own instruments and effects, 100+ presets and genre starter projects.

## Build it on GitHub (works from a phone)
1. Fork https://github.com/LMMS/lmms to your own account (Fork button).
2. In your fork open `.github/workflows`, tap **Add file > Upload files**, and upload `build-macos.yml`. Commit.
3. Go back to the repo root, tap **Add file > Upload files**, and upload `glasswork-overlay.zip`. Commit.
   (Uploading the zip starts an Apple Silicon build by itself.)
4. Open the **Actions** tab. If asked, enable workflows. You can disable LMMS's own workflows (Build, Checks,
   Doxygen) from the Actions sidebar so only `build-macos` runs.
5. When the run finishes, open it and download the **lmms-arm64-dmg** artifact (or check Releases for a
   `dmg-...` prerelease if the artifact upload failed). The first build is the slow one; later builds reuse caches.

If a Glasswork plugin ever fails to compile, the workflow retries once automatically in safe mode (without
Glasswork's own plugins). You can also run **build-macos** by hand with `glasswork_plugins` set to `off`.

## What's inside
- `plugins/Glasswork*` - Saw, Pluck, Metal, Bass instruments; Pump and Chorus effects
- `data/themes/nexus` - the theme (default when installed); `data/presets`, `data/projects/templates` - presets and starters
- `tools/build_presets.sh` - regenerates all presets and starter projects
- `docs/FL-STUDIO-EQUIVALENTS.md` - how Glasswork maps onto FL Studio's instruments
- `ci/`, `.github/actions/prep` - the sharded macOS build with cache fallbacks
- `cmake/apple/icon.icns`, `data/themes/nexus/icon*.png`, `splash.png` - the Nexus Glasswork app icon and splash screen

## Naming
The app shows as Glasswork / Nexus Glasswork everywhere you can see it (window title, About, dialogs, app and .dmg name,
splash, icon). Internal names stay `lmms` on purpose (the program, code namespaces, theme selectors, project file format) so
the build and existing LMMS projects keep working. Glasswork keeps its own settings (`~/.glassworkrc.xml`) and projects folder
(`~/Documents/Glasswork`), so it won't touch a regular LMMS install. LMMS credit and the GPL notices stay in place.
