/*
 * GlassworkBass.cpp - Glasswork Bass: filtered bass synthesizer (saw, square, sub, ladder filter, drive)
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#include "GlassworkBass.h"

#include <QDomElement>
#include <QGridLayout>

#include "AudioEngine.h"
#include "Engine.h"
#include "GlassworkDsp.h"
#include "GlassworkUi.h"
#include "InstrumentTrack.h"
#include "Knob.h"
#include "NotePlayHandle.h"
#include "embed.h"
#include "plugin_export.h"

namespace lmms
{

extern "C"
{

Plugin::Descriptor PLUGIN_EXPORT glassworkbass_plugin_descriptor =
{
	LMMS_STRINGIFY(PLUGIN_NAME),
	"Glasswork Bass",
	QT_TRANSLATE_NOOP("PluginBrowser", "Bass synthesizer with saw, square and sub oscillators, a resonant ladder filter with its own envelope, and drive"),
	"Glasswork",
	0x0100,
	Plugin::Type::Instrument,
	new PixmapLoader("lmms-plugin-logo"),
	nullptr,
	nullptr,
};

}

namespace
{

struct BassNote
{
	float sawPhase = 0.0f;
	float sqPhase = 0.0f;
	float subPhase = 0.0f;
	gw::Ladder filter;
	f_cnt_t t = 0;
};

} // namespace


GlassworkBass::GlassworkBass(InstrumentTrack* instrumentTrack) :
	Instrument(instrumentTrack, &glassworkbass_plugin_descriptor, nullptr, Flag::NoFlags),
	m_saw(0.7f, 0.0f, 1.0f, 0.01f, this, tr("Saw level")),
	m_square(0.3f, 0.0f, 1.0f, 0.01f, this, tr("Square level")),
	m_sub(0.6f, 0.0f, 1.0f, 0.01f, this, tr("Sub level")),
	m_cutoff(400.0f, 40.0f, 8000.0f, 1.0f, this, tr("Filter cutoff")),
	m_res(0.35f, 0.0f, 1.0f, 0.01f, this, tr("Resonance")),
	m_envamt(0.6f, 0.0f, 1.0f, 0.01f, this, tr("Filter envelope amount")),
	m_envdecay(220.0f, 20.0f, 1500.0f, 1.0f, this, tr("Filter envelope decay")),
	m_drive(0.25f, 0.0f, 1.0f, 0.01f, this, tr("Drive")),
	m_gain(1.0f, 0.0f, 2.0f, 0.01f, this, tr("Gain"))
{
}


void GlassworkBass::saveSettings(QDomDocument& doc, QDomElement& elem)
{
	m_saw.saveSettings(doc, elem, "saw");
	m_square.saveSettings(doc, elem, "square");
	m_sub.saveSettings(doc, elem, "sub");
	m_cutoff.saveSettings(doc, elem, "cutoff");
	m_res.saveSettings(doc, elem, "res");
	m_envamt.saveSettings(doc, elem, "envamt");
	m_envdecay.saveSettings(doc, elem, "envdecay");
	m_drive.saveSettings(doc, elem, "drive");
	m_gain.saveSettings(doc, elem, "gain");
}


void GlassworkBass::loadSettings(const QDomElement& elem)
{
	m_saw.loadSettings(elem, "saw");
	m_square.loadSettings(elem, "square");
	m_sub.loadSettings(elem, "sub");
	m_cutoff.loadSettings(elem, "cutoff");
	m_res.loadSettings(elem, "res");
	m_envamt.loadSettings(elem, "envamt");
	m_envdecay.loadSettings(elem, "envdecay");
	m_drive.loadSettings(elem, "drive");
	m_gain.loadSettings(elem, "gain");
}


QString GlassworkBass::nodeName() const
{
	return glassworkbass_plugin_descriptor.name;
}


void GlassworkBass::playNote(NotePlayHandle* n, SampleFrame* workingBuffer)
{
	const f_cnt_t frames = n->framesLeftForCurrentPeriod();
	const f_cnt_t offset = n->noteOffset();
	const float sampleRate = Engine::audioEngine()->outputSampleRate();

	if (!n->m_pluginData) { n->m_pluginData = new BassNote(); }
	auto* st = static_cast<BassNote*>(n->m_pluginData);

	const float freq = n->frequency();
	const float dt = std::clamp(freq / sampleRate, 0.0f, 0.45f);
	const float sawLevel = m_saw.value();
	const float sqLevel = m_square.value();
	const float subLevel = m_sub.value();
	const float baseCutoff = m_cutoff.value();
	const float res = m_res.value() * 0.95f;
	const float envOctaves = m_envamt.value() * 5.0f;
	const float envTau = std::max(m_envdecay.value(), 20.0f) * 0.001f * sampleRate;
	const float driveGain = 1.0f + m_drive.value() * 5.0f;
	const float driveNorm = 1.0f / std::tanh(driveGain);
	const float gain = m_gain.value();
	const float maxCutoff = std::min(0.17f * sampleRate, 12000.0f);

	for (f_cnt_t f = 0; f < frames; ++f)
	{
		const float saw = gw::sawBlep(st->sawPhase, dt);
		const float sq = gw::squareBlep(st->sqPhase, dt);
		const float sub = std::sin(gw::TwoPi * st->subPhase);
		st->sawPhase += dt; if (st->sawPhase >= 1.0f) { st->sawPhase -= 1.0f; }
		st->sqPhase += dt;  if (st->sqPhase >= 1.0f) { st->sqPhase -= 1.0f; }
		st->subPhase += dt * 0.5f; if (st->subPhase >= 1.0f) { st->subPhase -= 1.0f; }

		const float osc = (saw * sawLevel + sq * sqLevel + sub * subLevel) * 0.5f;
		const float env = std::exp(-static_cast<float>(st->t) / envTau);
		++st->t;
		const float cutoff = std::clamp(baseCutoff * std::pow(2.0f, envOctaves * env), 20.0f, maxCutoff);

		float out = st->filter.process(osc, cutoff, res, sampleRate) * (1.0f + res * 1.5f);
		out = std::tanh(out * driveGain) * driveNorm * gain;
		workingBuffer[offset + f][0] = out;
		workingBuffer[offset + f][1] = out;
	}
	gw::applyLinearRelease(n, workingBuffer, offset, frames, static_cast<float>(desiredReleaseFrames()));
}


void GlassworkBass::deleteNotePluginData(NotePlayHandle* n)
{
	delete static_cast<BassNote*>(n->m_pluginData);
}


gui::PluginView* GlassworkBass::instantiateView(QWidget* parent)
{
	return new gui::GlassworkBassView(this, parent);
}


namespace gui
{

GlassworkBassView::GlassworkBassView(Instrument* instrument, QWidget* parent) :
	InstrumentViewFixedSize(instrument, parent)
{
	auto* grid = new QGridLayout(this);
	grid->setContentsMargins(16, 16, 16, 16);
	grid->setSpacing(12);

	m_sawKnob = gwui::makeKnob(this, tr("SAW"), tr("Saw level:"), "");
	m_squareKnob = gwui::makeKnob(this, tr("SQUARE"), tr("Square level:"), "");
	m_subKnob = gwui::makeKnob(this, tr("SUB"), tr("Sub level:"), "");
	m_cutoffKnob = gwui::makeKnob(this, tr("CUTOFF"), tr("Filter cutoff:"), " Hz");
	m_resKnob = gwui::makeKnob(this, tr("RES"), tr("Resonance:"), "");
	m_envamtKnob = gwui::makeKnob(this, tr("ENV"), tr("Filter envelope amount:"), "");
	m_envdecayKnob = gwui::makeKnob(this, tr("DECAY"), tr("Filter envelope decay:"), " ms");
	m_driveKnob = gwui::makeKnob(this, tr("DRIVE"), tr("Drive:"), "");
	m_gainKnob = gwui::makeKnob(this, tr("GAIN"), tr("Gain:"), "");

	grid->addWidget(m_sawKnob, 0, 0, Qt::AlignHCenter);
	grid->addWidget(m_squareKnob, 0, 1, Qt::AlignHCenter);
	grid->addWidget(m_subKnob, 0, 2, Qt::AlignHCenter);
	grid->addWidget(m_cutoffKnob, 1, 0, Qt::AlignHCenter);
	grid->addWidget(m_resKnob, 1, 1, Qt::AlignHCenter);
	grid->addWidget(m_envamtKnob, 1, 2, Qt::AlignHCenter);
	grid->addWidget(m_envdecayKnob, 2, 0, Qt::AlignHCenter);
	grid->addWidget(m_driveKnob, 2, 1, Qt::AlignHCenter);
	grid->addWidget(m_gainKnob, 2, 2, Qt::AlignHCenter);
}


void GlassworkBassView::modelChanged()
{
	auto* s = castModel<GlassworkBass>();
	m_sawKnob->setModel(&s->m_saw);
	m_squareKnob->setModel(&s->m_square);
	m_subKnob->setModel(&s->m_sub);
	m_cutoffKnob->setModel(&s->m_cutoff);
	m_resKnob->setModel(&s->m_res);
	m_envamtKnob->setModel(&s->m_envamt);
	m_envdecayKnob->setModel(&s->m_envdecay);
	m_driveKnob->setModel(&s->m_drive);
	m_gainKnob->setModel(&s->m_gain);
}

} // namespace gui


extern "C"
{

// necessary for getting instance out of shared lib
PLUGIN_EXPORT Plugin* lmms_plugin_main(Model* model, void*)
{
	return new GlassworkBass(static_cast<InstrumentTrack*>(model));
}

}

} // namespace lmms
