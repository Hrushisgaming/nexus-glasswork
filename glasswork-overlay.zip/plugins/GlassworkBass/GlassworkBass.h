/*
 * GlassworkBass.h - Glasswork Bass: filtered bass synthesizer (saw, square, sub, ladder filter, drive)
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#ifndef LMMS_GLASSWORK_BASS_H
#define LMMS_GLASSWORK_BASS_H

#include "AutomatableModel.h"
#include "Instrument.h"
#include "InstrumentView.h"

namespace lmms
{

class NotePlayHandle;

namespace gui
{
class GlassworkBassView;
class Knob;
}

class GlassworkBass : public Instrument
{
	Q_OBJECT
public:
	GlassworkBass(InstrumentTrack* instrumentTrack);
	~GlassworkBass() override = default;

	void playNote(NotePlayHandle* n, SampleFrame* workingBuffer) override;
	void deleteNotePluginData(NotePlayHandle* n) override;

	void saveSettings(QDomDocument& doc, QDomElement& elem) override;
	void loadSettings(const QDomElement& elem) override;

	QString nodeName() const override;
	float desiredReleaseTimeMs() const override { return 40.f; }

	gui::PluginView* instantiateView(QWidget* parent) override;

private:
	FloatModel m_saw;
	FloatModel m_square;
	FloatModel m_sub;
	FloatModel m_cutoff;
	FloatModel m_res;
	FloatModel m_envamt;
	FloatModel m_envdecay;
	FloatModel m_drive;
	FloatModel m_gain;

	friend class gui::GlassworkBassView;
};

namespace gui
{

class GlassworkBassView : public InstrumentViewFixedSize
{
	Q_OBJECT
public:
	GlassworkBassView(Instrument* instrument, QWidget* parent);
	~GlassworkBassView() override = default;

private:
	void modelChanged() override;

	Knob* m_sawKnob;
	Knob* m_squareKnob;
	Knob* m_subKnob;
	Knob* m_cutoffKnob;
	Knob* m_resKnob;
	Knob* m_envamtKnob;
	Knob* m_envdecayKnob;
	Knob* m_driveKnob;
	Knob* m_gainKnob;
};

} // namespace gui

} // namespace lmms

#endif // LMMS_GLASSWORK_BASS_H
