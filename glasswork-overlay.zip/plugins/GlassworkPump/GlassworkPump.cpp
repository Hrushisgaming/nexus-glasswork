/*
 * GlassworkPump.cpp - Glasswork Pump: tempo-synced sidechain-style volume pumping
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#include "GlassworkPump.h"

#include <QDomElement>
#include <QGridLayout>
#include <QLabel>

#include <algorithm>
#include <cmath>

#include "AudioEngine.h"
#include "ComboBox.h"
#include "Engine.h"
#include "GlassworkUi.h"
#include "Knob.h"
#include "Song.h"
#include "Timeline.h"
#include "embed.h"
#include "plugin_export.h"

namespace lmms
{

extern "C"
{

Plugin::Descriptor PLUGIN_EXPORT glassworkpump_plugin_descriptor =
{
	LMMS_STRINGIFY(PLUGIN_NAME),
	"Glasswork Pump",
	QT_TRANSLATE_NOOP("PluginBrowser", "Tempo-synced volume pumping (sidechain-style ducking) without needing a sidechain signal"),
	"Glasswork",
	0x0100,
	Plugin::Type::Effect,
	new PixmapLoader("lmms-plugin-logo"),
	nullptr,
	nullptr,
};

}


GlassworkPumpControls::GlassworkPumpControls(GlassworkPumpEffect* effect) :
	EffectControls(effect),
	m_effect(effect),
	m_rate(this, tr("Rate")),
	m_depth(70.0f, 0.0f, 100.0f, 0.1f, this, tr("Depth")),
	m_curve(50.0f, 0.0f, 100.0f, 0.1f, this, tr("Curve")),
	m_shift(0.0f, 0.0f, 100.0f, 0.1f, this, tr("Shift"))
{
	m_rate.addItem("1/16");
	m_rate.addItem("1/8");
	m_rate.addItem("1/4 (every beat)");
	m_rate.addItem("1/2");
	m_rate.addItem("1 bar");
	m_rate.setValue(2);
}


void GlassworkPumpControls::saveSettings(QDomDocument& doc, QDomElement& parent)
{
	m_rate.saveSettings(doc, parent, "rate");
	m_depth.saveSettings(doc, parent, "depth");
	m_curve.saveSettings(doc, parent, "curve");
	m_shift.saveSettings(doc, parent, "shift");
}


void GlassworkPumpControls::loadSettings(const QDomElement& parent)
{
	m_rate.loadSettings(parent, "rate");
	m_depth.loadSettings(parent, "depth");
	m_curve.loadSettings(parent, "curve");
	m_shift.loadSettings(parent, "shift");
}


gui::EffectControlDialog* GlassworkPumpControls::createView()
{
	return new gui::GlassworkPumpDialog(this);
}


GlassworkPumpEffect::GlassworkPumpEffect(Model* parent, const Descriptor::SubPluginFeatures::Key* key) :
	Effect(&glassworkpump_plugin_descriptor, parent, key),
	m_controls(this)
{
}


Effect::ProcessStatus GlassworkPumpEffect::processImpl(SampleFrame* buf, const f_cnt_t frames)
{
	static constexpr double CycleBeats[5] = {0.25, 0.5, 1.0, 2.0, 4.0};
	constexpr double TicksPerBeat = 48.0; // a quarter note is 48 ticks (192 per bar)

	const float sampleRate = Engine::audioEngine()->outputSampleRate();
	const double cycleBeats = CycleBeats[std::clamp(m_controls.m_rate.value(), 0, 4)];
	const double framesPerCycle = std::max(static_cast<double>(Engine::framesPerTick()) * TicksPerBeat * cycleBeats, 1.0);
	const float depth = m_controls.m_depth.value() * 0.01f;
	const float curveExp = 0.4f + 2.6f * m_controls.m_curve.value() * 0.01f;
	const double shift = m_controls.m_shift.value() * 0.01;
	const float smoothCoef = 1.0f - std::exp(-1.0f / (0.0015f * sampleRate));

	// Lock to the song position while playing, free-run otherwise so the effect is audible when previewing.
	const Song* song = Engine::getSong();
	double startPhase = m_freePhase;
	if (song && song->isPlaying() && !song->isPaused())
	{
		const auto& timeline = song->getTimeline();
		const double positionFrames = static_cast<double>(timeline.ticks()) * Engine::framesPerTick() + timeline.frameOffset();
		startPhase = std::fmod(positionFrames / framesPerCycle, 1.0);
	}

	const float d = dryLevel();
	const float w = wetLevel();

	for (f_cnt_t f = 0; f < frames; ++f)
	{
		const double phase = std::fmod(startPhase + shift + static_cast<double>(f) / framesPerCycle, 1.0);
		const float target = 1.0f - depth * (1.0f - std::pow(static_cast<float>(phase), curveExp));
		m_smoothed += (target - m_smoothed) * smoothCoef;

		auto& frame = buf[f];
		const SampleFrame processed = frame * m_smoothed;
		frame = frame * d + processed * w;
	}

	m_freePhase = std::fmod(startPhase + static_cast<double>(frames) / framesPerCycle, 1.0);
	return ProcessStatus::ContinueIfNotQuiet;
}


namespace gui
{

GlassworkPumpDialog::GlassworkPumpDialog(GlassworkPumpControls* controls) :
	EffectControlDialog(controls)
{
	auto* grid = new QGridLayout(this);
	grid->setContentsMargins(14, 12, 14, 12);
	grid->setSpacing(10);

	auto* rateLabel = new QLabel(tr("RATE"), this);
	auto* rateBox = new ComboBox(this);
	rateBox->setFixedSize(120, 22);
	rateBox->setModel(&controls->m_rate);

	auto* depth = gwui::makeKnob(this, tr("DEPTH"), tr("Depth:"), "%");
	depth->setModel(&controls->m_depth);
	auto* curve = gwui::makeKnob(this, tr("CURVE"), tr("Curve (recovery shape):"), "%");
	curve->setModel(&controls->m_curve);
	auto* shift = gwui::makeKnob(this, tr("SHIFT"), tr("Shift:"), "%");
	shift->setModel(&controls->m_shift);

	grid->addWidget(rateLabel, 0, 0, Qt::AlignHCenter);
	grid->addWidget(rateBox, 1, 0, Qt::AlignHCenter);
	grid->addWidget(depth, 0, 1, 2, 1, Qt::AlignHCenter);
	grid->addWidget(curve, 0, 2, 2, 1, Qt::AlignHCenter);
	grid->addWidget(shift, 0, 3, 2, 1, Qt::AlignHCenter);
	grid->setSizeConstraint(QLayout::SetFixedSize);
}

} // namespace gui


extern "C"
{

// necessary for getting instance out of shared lib
PLUGIN_EXPORT Plugin* lmms_plugin_main(Model* parent, void* data)
{
	return new GlassworkPumpEffect(parent, static_cast<const Plugin::Descriptor::SubPluginFeatures::Key*>(data));
}

}

} // namespace lmms
