/*
 * GlassworkPump.h - Glasswork Pump: tempo-synced sidechain-style volume pumping
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#ifndef LMMS_GLASSWORK_PUMP_H
#define LMMS_GLASSWORK_PUMP_H

#include "ComboBoxModel.h"
#include "Effect.h"
#include "EffectControlDialog.h"
#include "EffectControls.h"

namespace lmms
{

class GlassworkPumpEffect;

namespace gui
{
class GlassworkPumpDialog;
}

class GlassworkPumpControls : public EffectControls
{
	Q_OBJECT
public:
	GlassworkPumpControls(GlassworkPumpEffect* effect);
	~GlassworkPumpControls() override = default;

	void saveSettings(QDomDocument& doc, QDomElement& parent) override;
	void loadSettings(const QDomElement& parent) override;
	inline QString nodeName() const override { return "GlassworkPumpControls"; }
	gui::EffectControlDialog* createView() override;
	int controlCount() override { return 4; }

private:
	GlassworkPumpEffect* m_effect;
	ComboBoxModel m_rate;
	FloatModel m_depth;
	FloatModel m_curve;
	FloatModel m_shift;

	friend class gui::GlassworkPumpDialog;
	friend class GlassworkPumpEffect;
};


class GlassworkPumpEffect : public Effect
{
public:
	GlassworkPumpEffect(Model* parent, const Descriptor::SubPluginFeatures::Key* key);
	~GlassworkPumpEffect() override = default;

	ProcessStatus processImpl(SampleFrame* buf, const f_cnt_t frames) override;

	EffectControls* controls() override { return &m_controls; }

private:
	GlassworkPumpControls m_controls;
	float m_smoothed = 1.0f;
	double m_freePhase = 0.0;

	friend class GlassworkPumpControls;
};


namespace gui
{

class GlassworkPumpDialog : public EffectControlDialog
{
	Q_OBJECT
public:
	GlassworkPumpDialog(GlassworkPumpControls* controls);
	~GlassworkPumpDialog() override = default;
};

} // namespace gui

} // namespace lmms

#endif // LMMS_GLASSWORK_PUMP_H
