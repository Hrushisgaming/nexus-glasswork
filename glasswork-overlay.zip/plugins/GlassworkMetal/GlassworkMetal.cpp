/*
 * GlassworkMetal.cpp - Glasswork Metal: metallic percussion synthesizer for cymbals and hats
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#include "GlassworkMetal.h"

#include <QDomElement>
#include <QGridLayout>

#include "AudioEngine.h"
#include "Engine.h"
#include "GlassworkDsp.h"
#include "GlassworkUi.h"
#include "InstrumentTrack.h"
#include "Knob.h"
#include "NotePlayHandle.h"
#include "embed.h"
#include "plugin_export.h"

namespace lmms
{

extern "C"
{

Plugin::Descriptor PLUGIN_EXPORT glassworkmetal_plugin_descriptor =
{
	LMMS_STRINGIFY(PLUGIN_NAME),
	"Glasswork Metal",
	QT_TRANSLATE_NOOP("PluginBrowser", "Metallic percussion synthesizer: six detuned square oscillators plus noise for crashes, rides, hats and bells"),
	"Glasswork",
	0x0100,
	Plugin::Type::Instrument,
	new PixmapLoader("lmms-plugin-logo"),
	nullptr,
	nullptr,
};

}

namespace
{

struct MetalNote
{
	float phase[6] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
	gw::Rng rng;
	gw::Svf filter;
	f_cnt_t t = 0;
	explicit MetalNote(uint32_t seed) : rng(seed) {}
};

// The six square-wave frequencies of the classic analogue hi-hat/cymbal circuit.
constexpr float MetalFreqs[6] = {205.3f, 304.4f, 369.6f, 522.7f, 540.0f, 800.0f};

} // namespace


GlassworkMetal::GlassworkMetal(InstrumentTrack* instrumentTrack) :
	Instrument(instrumentTrack, &glassworkmetal_plugin_descriptor, nullptr, Flag::IsNotBendable),
	m_tune(1.0f, 0.5f, 2.0f, 0.01f, this, tr("Tune")),
	m_metal(0.8f, 0.0f, 1.0f, 0.01f, this, tr("Metallic level")),
	m_noise(0.35f, 0.0f, 1.0f, 0.01f, this, tr("Noise level")),
	m_tone(6500.0f, 1000.0f, 12000.0f, 10.0f, this, tr("Brightness (high-pass)")),
	m_body(0.2f, 0.0f, 1.0f, 0.01f, this, tr("Body")),
	m_decay(300.0f, 20.0f, 4000.0f, 1.0f, this, tr("Decay")),
	m_tail(0.2f, 0.0f, 1.0f, 0.01f, this, tr("Long tail")),
	m_keytrack(0.0f, 0.0f, 1.0f, 0.01f, this, tr("Key tracking")),
	m_gain(1.0f, 0.0f, 2.0f, 0.01f, this, tr("Gain"))
{
}


void GlassworkMetal::saveSettings(QDomDocument& doc, QDomElement& elem)
{
	m_tune.saveSettings(doc, elem, "tune");
	m_metal.saveSettings(doc, elem, "metal");
	m_noise.saveSettings(doc, elem, "noise");
	m_tone.saveSettings(doc, elem, "tone");
	m_body.saveSettings(doc, elem, "body");
	m_decay.saveSettings(doc, elem, "decay");
	m_tail.saveSettings(doc, elem, "tail");
	m_keytrack.saveSettings(doc, elem, "keytrack");
	m_gain.saveSettings(doc, elem, "gain");
}


void GlassworkMetal::loadSettings(const QDomElement& elem)
{
	m_tune.loadSettings(elem, "tune");
	m_metal.loadSettings(elem, "metal");
	m_noise.loadSettings(elem, "noise");
	m_tone.loadSettings(elem, "tone");
	m_body.loadSettings(elem, "body");
	m_decay.loadSettings(elem, "decay");
	m_tail.loadSettings(elem, "tail");
	m_keytrack.loadSettings(elem, "keytrack");
	m_gain.loadSettings(elem, "gain");
}


QString GlassworkMetal::nodeName() const
{
	return glassworkmetal_plugin_descriptor.name;
}


void GlassworkMetal::playNote(NotePlayHandle* n, SampleFrame* workingBuffer)
{
	const f_cnt_t frames = n->framesLeftForCurrentPeriod();
	const f_cnt_t offset = n->noteOffset();
	const float sampleRate = Engine::audioEngine()->outputSampleRate();

	if (!n->m_pluginData)
	{
		n->m_pluginData = new MetalNote(static_cast<uint32_t>(reinterpret_cast<std::uintptr_t>(n) >> 4) ^ 0xC2B2AE35u);
	}
	auto* st = static_cast<MetalNote*>(n->m_pluginData);

	const float keyAmount = m_keytrack.value();
	const float ratio = m_tune.value() * (keyAmount > 0.001f ? std::pow(std::max(n->frequency(), 20.0f) / 440.0f, keyAmount) : 1.0f);
	const float metalLevel = m_metal.value();
	const float noiseLevel = m_noise.value() * 0.6f;
	const float bodyLevel = m_body.value();
	const float gain = m_gain.value();
	const float g = gw::svfG(m_tone.value(), sampleRate);
	const float k = 1.0f / 0.9f;
	const float decaySec = std::max(m_decay.value(), 20.0f) * 0.001f;
	const float tail = m_tail.value();
	const float tau1 = decaySec / 6.9078f;          // -60 dB after 'decay'
	const float tau2 = tau1 * 3.5f;
	const float attackFrames = std::max(0.0005f * sampleRate, 1.0f);

	float dt[6];
	for (int i = 0; i < 6; ++i) { dt[i] = std::clamp(MetalFreqs[i] * ratio / sampleRate, 0.0f, 0.45f); }

	for (f_cnt_t f = 0; f < frames; ++f)
	{
		float metal = 0.0f;
		for (int i = 0; i < 6; ++i)
		{
			metal += gw::squareBlep(st->phase[i], dt[i]);
			float next = st->phase[i] + dt[i];
			if (next >= 1.0f) { next -= 1.0f; }
			st->phase[i] = next;
		}
		metal *= (1.0f / 6.0f) * 1.6f;

		const float input = metal * metalLevel + st->rng.bi() * noiseLevel;
		st->filter.process(input, g, k);
		const float shaped = st->filter.hp + bodyLevel * st->filter.bp;

		const float tSec = static_cast<float>(st->t) / sampleRate;
		const float env = (1.0f - tail) * std::exp(-tSec / tau1) + tail * std::exp(-tSec / tau2);
		const float attack = std::min(1.0f, static_cast<float>(st->t) / attackFrames);
		++st->t;

		const float out = shaped * env * attack * gain;
		workingBuffer[offset + f][0] = out;
		workingBuffer[offset + f][1] = out;
	}
}


void GlassworkMetal::deleteNotePluginData(NotePlayHandle* n)
{
	delete static_cast<MetalNote*>(n->m_pluginData);
}


gui::PluginView* GlassworkMetal::instantiateView(QWidget* parent)
{
	return new gui::GlassworkMetalView(this, parent);
}


namespace gui
{

GlassworkMetalView::GlassworkMetalView(Instrument* instrument, QWidget* parent) :
	InstrumentViewFixedSize(instrument, parent)
{
	auto* grid = new QGridLayout(this);
	grid->setContentsMargins(16, 16, 16, 16);
	grid->setSpacing(12);

	m_tuneKnob = gwui::makeKnob(this, tr("TUNE"), tr("Tune:"), "");
	m_metalKnob = gwui::makeKnob(this, tr("METAL"), tr("Metallic level:"), "");
	m_noiseKnob = gwui::makeKnob(this, tr("NOISE"), tr("Noise level:"), "");
	m_toneKnob = gwui::makeKnob(this, tr("TONE"), tr("Brightness (high-pass):"), " Hz");
	m_bodyKnob = gwui::makeKnob(this, tr("BODY"), tr("Body:"), "");
	m_decayKnob = gwui::makeKnob(this, tr("DECAY"), tr("Decay:"), " ms");
	m_tailKnob = gwui::makeKnob(this, tr("TAIL"), tr("Long tail:"), "");
	m_keytrackKnob = gwui::makeKnob(this, tr("KEY"), tr("Key tracking:"), "");
	m_gainKnob = gwui::makeKnob(this, tr("GAIN"), tr("Gain:"), "");

	grid->addWidget(m_tuneKnob, 0, 0, Qt::AlignHCenter);
	grid->addWidget(m_metalKnob, 0, 1, Qt::AlignHCenter);
	grid->addWidget(m_noiseKnob, 0, 2, Qt::AlignHCenter);
	grid->addWidget(m_toneKnob, 1, 0, Qt::AlignHCenter);
	grid->addWidget(m_bodyKnob, 1, 1, Qt::AlignHCenter);
	grid->addWidget(m_decayKnob, 1, 2, Qt::AlignHCenter);
	grid->addWidget(m_tailKnob, 2, 0, Qt::AlignHCenter);
	grid->addWidget(m_keytrackKnob, 2, 1, Qt::AlignHCenter);
	grid->addWidget(m_gainKnob, 2, 2, Qt::AlignHCenter);
}


void GlassworkMetalView::modelChanged()
{
	auto* s = castModel<GlassworkMetal>();
	m_tuneKnob->setModel(&s->m_tune);
	m_metalKnob->setModel(&s->m_metal);
	m_noiseKnob->setModel(&s->m_noise);
	m_toneKnob->setModel(&s->m_tone);
	m_bodyKnob->setModel(&s->m_body);
	m_decayKnob->setModel(&s->m_decay);
	m_tailKnob->setModel(&s->m_tail);
	m_keytrackKnob->setModel(&s->m_keytrack);
	m_gainKnob->setModel(&s->m_gain);
}

} // namespace gui


extern "C"
{

// necessary for getting instance out of shared lib
PLUGIN_EXPORT Plugin* lmms_plugin_main(Model* model, void*)
{
	return new GlassworkMetal(static_cast<InstrumentTrack*>(model));
}

}

} // namespace lmms
