/*
 * GlassworkMetal.h - Glasswork Metal: metallic percussion synthesizer for cymbals and hats
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#ifndef LMMS_GLASSWORK_METAL_H
#define LMMS_GLASSWORK_METAL_H

#include "AutomatableModel.h"
#include "Instrument.h"
#include "InstrumentView.h"

namespace lmms
{

class NotePlayHandle;

namespace gui
{
class GlassworkMetalView;
class Knob;
}

class GlassworkMetal : public Instrument
{
	Q_OBJECT
public:
	GlassworkMetal(InstrumentTrack* instrumentTrack);
	~GlassworkMetal() override = default;

	void playNote(NotePlayHandle* n, SampleFrame* workingBuffer) override;
	void deleteNotePluginData(NotePlayHandle* n) override;

	void saveSettings(QDomDocument& doc, QDomElement& elem) override;
	void loadSettings(const QDomElement& elem) override;

	QString nodeName() const override;
	float desiredReleaseTimeMs() const override { return std::max(m_decay.value(), 20.0f) * (1.0f + 2.5f * m_tail.value()) * 1.15f; }

	gui::PluginView* instantiateView(QWidget* parent) override;

private:
	FloatModel m_tune;
	FloatModel m_metal;
	FloatModel m_noise;
	FloatModel m_tone;
	FloatModel m_body;
	FloatModel m_decay;
	FloatModel m_tail;
	FloatModel m_keytrack;
	FloatModel m_gain;

	friend class gui::GlassworkMetalView;
};

namespace gui
{

class GlassworkMetalView : public InstrumentViewFixedSize
{
	Q_OBJECT
public:
	GlassworkMetalView(Instrument* instrument, QWidget* parent);
	~GlassworkMetalView() override = default;

private:
	void modelChanged() override;

	Knob* m_tuneKnob;
	Knob* m_metalKnob;
	Knob* m_noiseKnob;
	Knob* m_toneKnob;
	Knob* m_bodyKnob;
	Knob* m_decayKnob;
	Knob* m_tailKnob;
	Knob* m_keytrackKnob;
	Knob* m_gainKnob;
};

} // namespace gui

} // namespace lmms

#endif // LMMS_GLASSWORK_METAL_H
