/*
 * GlassworkSaw.cpp - Glasswork Saw: a unison "supersaw" synthesizer
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#include "GlassworkSaw.h"

#include <QDomElement>
#include <QGridLayout>

#include "AudioEngine.h"
#include "Engine.h"
#include "GlassworkDsp.h"
#include "GlassworkUi.h"
#include "InstrumentTrack.h"
#include "Knob.h"
#include "NotePlayHandle.h"
#include "embed.h"
#include "plugin_export.h"

namespace lmms
{

extern "C"
{

Plugin::Descriptor PLUGIN_EXPORT glassworksaw_plugin_descriptor =
{
	LMMS_STRINGIFY(PLUGIN_NAME),
	"Glasswork Saw",
	QT_TRANSLATE_NOOP("PluginBrowser", "Unison supersaw synthesizer: up to 9 detuned, band-limited saw/square voices with stereo spread"),
	"Glasswork",
	0x0100,
	Plugin::Type::Instrument,
	new PixmapLoader("lmms-plugin-logo"),
	nullptr,
	nullptr,
};

}

namespace
{

constexpr int MaxVoices = 9;

struct SawNote
{
	float phase[MaxVoices];
	float subPhase = 0.0f;

	explicit SawNote(uint32_t seed)
	{
		gw::Rng rng(seed);
		for (auto& p : phase) { p = rng.uni(); }
	}
};

} // namespace


GlassworkSaw::GlassworkSaw(InstrumentTrack* instrumentTrack) :
	Instrument(instrumentTrack, &glassworksaw_plugin_descriptor, nullptr, Flag::NoFlags),
	m_voices(7.0f, 1.0f, static_cast<float>(MaxVoices), 1.0f, this, tr("Voices")),
	m_detune(18.0f, 0.0f, 100.0f, 0.1f, this, tr("Detune")),
	m_spread(0.8f, 0.0f, 1.0f, 0.01f, this, tr("Stereo spread")),
	m_shape(0.0f, 0.0f, 1.0f, 0.01f, this, tr("Shape (saw to square)")),
	m_sub(0.0f, 0.0f, 1.0f, 0.01f, this, tr("Sub oscillator")),
	m_drive(0.15f, 0.0f, 1.0f, 0.01f, this, tr("Drive")),
	m_gain(1.0f, 0.0f, 2.0f, 0.01f, this, tr("Gain"))
{
}


void GlassworkSaw::saveSettings(QDomDocument& doc, QDomElement& elem)
{
	m_voices.saveSettings(doc, elem, "voices");
	m_detune.saveSettings(doc, elem, "detune");
	m_spread.saveSettings(doc, elem, "spread");
	m_shape.saveSettings(doc, elem, "shape");
	m_sub.saveSettings(doc, elem, "sub");
	m_drive.saveSettings(doc, elem, "drive");
	m_gain.saveSettings(doc, elem, "gain");
}


void GlassworkSaw::loadSettings(const QDomElement& elem)
{
	m_voices.loadSettings(elem, "voices");
	m_detune.loadSettings(elem, "detune");
	m_spread.loadSettings(elem, "spread");
	m_shape.loadSettings(elem, "shape");
	m_sub.loadSettings(elem, "sub");
	m_drive.loadSettings(elem, "drive");
	m_gain.loadSettings(elem, "gain");
}


QString GlassworkSaw::nodeName() const
{
	return glassworksaw_plugin_descriptor.name;
}


void GlassworkSaw::playNote(NotePlayHandle* n, SampleFrame* workingBuffer)
{
	const f_cnt_t frames = n->framesLeftForCurrentPeriod();
	const f_cnt_t offset = n->noteOffset();
	const float sampleRate = Engine::audioEngine()->outputSampleRate();

	if (!n->m_pluginData)
	{
		const auto seed = static_cast<uint32_t>(reinterpret_cast<std::uintptr_t>(n) >> 4) ^ 0x9E3779B9u;
		n->m_pluginData = new SawNote(seed);
	}
	auto* note = static_cast<SawNote*>(n->m_pluginData);

	const int voices = std::clamp(static_cast<int>(std::lround(m_voices.value())), 1, MaxVoices);
	const float freq = n->frequency();
	const float detuneCents = m_detune.value();
	const float spread = m_spread.value();
	const float shape = m_shape.value();
	const float subLevel = m_sub.value();
	const float drive = m_drive.value();
	const float driveGain = 1.0f + drive * 6.0f;
	const float driveNorm = 1.0f / std::tanh(driveGain);
	const float norm = 0.55f / std::sqrt(static_cast<float>(voices));
	const float gain = m_gain.value();

	float dt[MaxVoices];
	float gainL[MaxVoices];
	float gainR[MaxVoices];
	for (int v = 0; v < voices; ++v)
	{
		const float pos = voices == 1 ? 0.0f : (2.0f * static_cast<float>(v) / static_cast<float>(voices - 1)) - 1.0f; // -1..1
		const float ratio = std::pow(2.0f, pos * detuneCents / 1200.0f);
		dt[v] = std::clamp(freq * ratio / sampleRate, 0.0f, 0.45f);
		const float angle = (std::clamp(pos * spread, -1.0f, 1.0f) + 1.0f) * gw::Pi * 0.25f; // 0..pi/2, equal power pan
		gainL[v] = std::cos(angle);
		gainR[v] = std::sin(angle);
	}
	const float subInc = freq * 0.5f / sampleRate;

	for (f_cnt_t f = 0; f < frames; ++f)
	{
		float left = 0.0f;
		float right = 0.0f;
		for (int v = 0; v < voices; ++v)
		{
			const float ph = note->phase[v];
			const float saw = gw::sawBlep(ph, dt[v]);
			const float sq = gw::squareBlep(ph, dt[v]);
			const float s = saw + shape * (sq - saw);
			left += s * gainL[v];
			right += s * gainR[v];
			float next = ph + dt[v];
			if (next >= 1.0f) { next -= 1.0f; }
			note->phase[v] = next;
		}

		const float sub = std::sin(gw::TwoPi * note->subPhase) * subLevel * 0.5f;
		note->subPhase += subInc;
		if (note->subPhase >= 1.0f) { note->subPhase -= 1.0f; }

		left = left * norm + sub;
		right = right * norm + sub;
		if (drive > 0.001f)
		{
			left = std::tanh(left * driveGain) * driveNorm;
			right = std::tanh(right * driveGain) * driveNorm;
		}

		workingBuffer[offset + f][0] = left * gain;
		workingBuffer[offset + f][1] = right * gain;
	}

	gw::applyLinearRelease(n, workingBuffer, offset, frames, static_cast<float>(desiredReleaseFrames()));
}


void GlassworkSaw::deleteNotePluginData(NotePlayHandle* n)
{
	delete static_cast<SawNote*>(n->m_pluginData);
}


gui::PluginView* GlassworkSaw::instantiateView(QWidget* parent)
{
	return new gui::GlassworkSawView(this, parent);
}


namespace gui
{

GlassworkSawView::GlassworkSawView(Instrument* instrument, QWidget* parent) :
	InstrumentViewFixedSize(instrument, parent)
{
	auto* grid = new QGridLayout(this);
	grid->setContentsMargins(16, 16, 16, 16);
	grid->setSpacing(12);

	m_voicesKnob = gwui::makeKnob(this, tr("VOICES"), tr("Voices:"), "");
	m_detuneKnob = gwui::makeKnob(this, tr("DETUNE"), tr("Detune:"), " cents");
	m_spreadKnob = gwui::makeKnob(this, tr("SPREAD"), tr("Stereo spread:"), "");
	m_shapeKnob = gwui::makeKnob(this, tr("SHAPE"), tr("Shape (saw to square):"), "");
	m_subKnob = gwui::makeKnob(this, tr("SUB"), tr("Sub oscillator:"), "");
	m_driveKnob = gwui::makeKnob(this, tr("DRIVE"), tr("Drive:"), "");
	m_gainKnob = gwui::makeKnob(this, tr("GAIN"), tr("Gain:"), "");

	grid->addWidget(m_voicesKnob, 0, 0, Qt::AlignHCenter);
	grid->addWidget(m_detuneKnob, 0, 1, Qt::AlignHCenter);
	grid->addWidget(m_spreadKnob, 0, 2, Qt::AlignHCenter);
	grid->addWidget(m_shapeKnob, 1, 0, Qt::AlignHCenter);
	grid->addWidget(m_subKnob, 1, 1, Qt::AlignHCenter);
	grid->addWidget(m_driveKnob, 1, 2, Qt::AlignHCenter);
	grid->addWidget(m_gainKnob, 2, 1, Qt::AlignHCenter);
}


void GlassworkSawView::modelChanged()
{
	auto* s = castModel<GlassworkSaw>();
	m_voicesKnob->setModel(&s->m_voices);
	m_detuneKnob->setModel(&s->m_detune);
	m_spreadKnob->setModel(&s->m_spread);
	m_shapeKnob->setModel(&s->m_shape);
	m_subKnob->setModel(&s->m_sub);
	m_driveKnob->setModel(&s->m_drive);
	m_gainKnob->setModel(&s->m_gain);
}

} // namespace gui


extern "C"
{

// necessary for getting instance out of shared lib
PLUGIN_EXPORT Plugin* lmms_plugin_main(Model* model, void*)
{
	return new GlassworkSaw(static_cast<InstrumentTrack*>(model));
}

}

} // namespace lmms
