/*
 * GlassworkSaw.h - Glasswork Saw: a unison "supersaw" synthesizer
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#ifndef LMMS_GLASSWORK_SAW_H
#define LMMS_GLASSWORK_SAW_H

#include "AutomatableModel.h"
#include "Instrument.h"
#include "InstrumentView.h"

namespace lmms
{

class NotePlayHandle;

namespace gui
{
class GlassworkSawView;
class Knob;
}

class GlassworkSaw : public Instrument
{
	Q_OBJECT
public:
	GlassworkSaw(InstrumentTrack* instrumentTrack);
	~GlassworkSaw() override = default;

	void playNote(NotePlayHandle* n, SampleFrame* workingBuffer) override;
	void deleteNotePluginData(NotePlayHandle* n) override;

	void saveSettings(QDomDocument& doc, QDomElement& elem) override;
	void loadSettings(const QDomElement& elem) override;

	QString nodeName() const override;
	float desiredReleaseTimeMs() const override { return 25.f; }

	gui::PluginView* instantiateView(QWidget* parent) override;

private:
	FloatModel m_voices;
	FloatModel m_detune;
	FloatModel m_spread;
	FloatModel m_shape;
	FloatModel m_sub;
	FloatModel m_drive;
	FloatModel m_gain;

	friend class gui::GlassworkSawView;
};

namespace gui
{

class GlassworkSawView : public InstrumentViewFixedSize
{
	Q_OBJECT
public:
	GlassworkSawView(Instrument* instrument, QWidget* parent);
	~GlassworkSawView() override = default;

private:
	void modelChanged() override;

	Knob* m_voicesKnob;
	Knob* m_detuneKnob;
	Knob* m_spreadKnob;
	Knob* m_shapeKnob;
	Knob* m_subKnob;
	Knob* m_driveKnob;
	Knob* m_gainKnob;
};

} // namespace gui

} // namespace lmms

#endif // LMMS_GLASSWORK_SAW_H
