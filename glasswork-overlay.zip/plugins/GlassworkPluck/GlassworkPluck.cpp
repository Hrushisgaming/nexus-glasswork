/*
 * GlassworkPluck.cpp - Glasswork Pluck: Karplus-Strong plucked string synthesizer
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#include "GlassworkPluck.h"

#include <QDomElement>
#include <QGridLayout>
#include <vector>

#include "AudioEngine.h"
#include "Engine.h"
#include "GlassworkDsp.h"
#include "GlassworkUi.h"
#include "InstrumentTrack.h"
#include "Knob.h"
#include "NotePlayHandle.h"
#include "embed.h"
#include "plugin_export.h"

namespace lmms
{

extern "C"
{

Plugin::Descriptor PLUGIN_EXPORT glassworkpluck_plugin_descriptor =
{
	LMMS_STRINGIFY(PLUGIN_NAME),
	"Glasswork Pluck",
	QT_TRANSLATE_NOOP("PluginBrowser", "Plucked string synthesizer (Karplus-Strong) for plucks, harps, guitars and mallets"),
	"Glasswork",
	0x0100,
	Plugin::Type::Instrument,
	new PixmapLoader("lmms-plugin-logo"),
	nullptr,
	nullptr,
};

}

namespace
{

struct PluckNote
{
	std::vector<float> line;
	int pos = 0;
	float lp = 0.0f;
	float apIn = 0.0f;
	float apOut = 0.0f;
	float apCoef = 0.0f;
	explicit PluckNote(int length) : line(static_cast<size_t>(std::max(length, 2)), 0.0f) {}
};

} // namespace


GlassworkPluck::GlassworkPluck(InstrumentTrack* instrumentTrack) :
	Instrument(instrumentTrack, &glassworkpluck_plugin_descriptor, nullptr, Flag::NoFlags),
	m_decay(0.6f, 0.0f, 1.0f, 0.01f, this, tr("Decay")),
	m_damping(0.35f, 0.0f, 1.0f, 0.01f, this, tr("Damping")),
	m_bright(0.6f, 0.02f, 1.0f, 0.01f, this, tr("Pick brightness")),
	m_pick(0.12f, 0.0f, 0.5f, 0.01f, this, tr("Pick position")),
	m_gain(1.0f, 0.0f, 2.0f, 0.01f, this, tr("Gain"))
{
}


void GlassworkPluck::saveSettings(QDomDocument& doc, QDomElement& elem)
{
	m_decay.saveSettings(doc, elem, "decay");
	m_damping.saveSettings(doc, elem, "damping");
	m_bright.saveSettings(doc, elem, "bright");
	m_pick.saveSettings(doc, elem, "pick");
	m_gain.saveSettings(doc, elem, "gain");
}


void GlassworkPluck::loadSettings(const QDomElement& elem)
{
	m_decay.loadSettings(elem, "decay");
	m_damping.loadSettings(elem, "damping");
	m_bright.loadSettings(elem, "bright");
	m_pick.loadSettings(elem, "pick");
	m_gain.loadSettings(elem, "gain");
}


QString GlassworkPluck::nodeName() const
{
	return glassworkpluck_plugin_descriptor.name;
}


void GlassworkPluck::playNote(NotePlayHandle* n, SampleFrame* workingBuffer)
{
	const f_cnt_t frames = n->framesLeftForCurrentPeriod();
	const f_cnt_t offset = n->noteOffset();
	const float sampleRate = Engine::audioEngine()->outputSampleRate();
	const float freq = n->frequency();

	if (!n->m_pluginData)
	{
		const float damp = std::clamp(m_damping.value(), 0.0f, 1.0f) * 0.85f * std::min(1.0f, std::pow(440.0f / std::max(freq, 20.0f), 0.7f));
		const float lpDelay = damp / (1.0f - damp);
		const float total = std::max(sampleRate / std::max(freq, 20.0f) - lpDelay, 4.0f);
		const int len = std::max(static_cast<int>(std::floor(total - 0.5f)), 2);
		const float frac = total - static_cast<float>(len);     // 0.5 .. 1.5 samples handled by the all-pass
		auto* st = new PluckNote(len);
		st->apCoef = (1.0f - frac) / (1.0f + frac);

		gw::Rng rng(static_cast<uint32_t>(reinterpret_cast<std::uintptr_t>(n) >> 4) ^ 0x85EBCA6Bu);
		const float bright = std::clamp(m_bright.value(), 0.02f, 1.0f);
		float e = 0.0f;
		float mean = 0.0f;
		for (int i = 0; i < len; ++i)
		{
			e += (rng.bi() - e) * bright;
			st->line[static_cast<size_t>(i)] = e;
			mean += e;
		}
		mean /= static_cast<float>(len);
		for (auto& v : st->line) { v -= mean; }

		const int k = static_cast<int>(m_pick.value() * static_cast<float>(len));
		if (k > 0 && k < len)
		{
			for (int i = len - 1; i >= k; --i) { st->line[static_cast<size_t>(i)] -= st->line[static_cast<size_t>(i - k)]; }
		}
		float peak = 1e-6f;
		for (float v : st->line) { peak = std::max(peak, std::fabs(v)); }
		for (auto& v : st->line) { v *= 0.9f / peak; }
		n->m_pluginData = st;
	}
	auto* st = static_cast<PluckNote*>(n->m_pluginData);

	const float damp = std::clamp(m_damping.value(), 0.0f, 1.0f) * 0.85f * std::min(1.0f, std::pow(440.0f / std::max(freq, 20.0f), 0.7f));
	const float baseFb = 1.0f - std::pow(10.0f, -(1.0f + 3.0f * std::clamp(m_decay.value(), 0.0f, 1.0f)));
	const float fb = std::pow(baseFb, 220.0f / std::max(freq, 20.0f));
	const float gain = m_gain.value();
	const int len = static_cast<int>(st->line.size());

	for (f_cnt_t f = 0; f < frames; ++f)
	{
		const float x = st->line[static_cast<size_t>(st->pos)];
		st->lp = (1.0f - damp) * x + damp * st->lp;
		const float fbSample = st->lp * fb;
		const float ap = st->apCoef * fbSample + st->apIn - st->apCoef * st->apOut;
		st->apIn = fbSample;
		st->apOut = ap;
		st->line[static_cast<size_t>(st->pos)] = ap;
		if (++st->pos >= len) { st->pos = 0; }

		const float out = x * gain * 0.8f;
		workingBuffer[offset + f][0] = out;
		workingBuffer[offset + f][1] = out;
	}
	gw::applyLinearRelease(n, workingBuffer, offset, frames, static_cast<float>(desiredReleaseFrames()));
}


void GlassworkPluck::deleteNotePluginData(NotePlayHandle* n)
{
	delete static_cast<PluckNote*>(n->m_pluginData);
}


gui::PluginView* GlassworkPluck::instantiateView(QWidget* parent)
{
	return new gui::GlassworkPluckView(this, parent);
}


namespace gui
{

GlassworkPluckView::GlassworkPluckView(Instrument* instrument, QWidget* parent) :
	InstrumentViewFixedSize(instrument, parent)
{
	auto* grid = new QGridLayout(this);
	grid->setContentsMargins(16, 16, 16, 16);
	grid->setSpacing(12);

	m_decayKnob = gwui::makeKnob(this, tr("DECAY"), tr("Decay:"), "");
	m_dampingKnob = gwui::makeKnob(this, tr("DAMPING"), tr("Damping:"), "");
	m_brightKnob = gwui::makeKnob(this, tr("BRIGHT"), tr("Pick brightness:"), "");
	m_pickKnob = gwui::makeKnob(this, tr("PICK"), tr("Pick position:"), "");
	m_gainKnob = gwui::makeKnob(this, tr("GAIN"), tr("Gain:"), "");

	grid->addWidget(m_decayKnob, 0, 0, Qt::AlignHCenter);
	grid->addWidget(m_dampingKnob, 0, 1, Qt::AlignHCenter);
	grid->addWidget(m_brightKnob, 0, 2, Qt::AlignHCenter);
	grid->addWidget(m_pickKnob, 1, 0, Qt::AlignHCenter);
	grid->addWidget(m_gainKnob, 1, 1, Qt::AlignHCenter);
}


void GlassworkPluckView::modelChanged()
{
	auto* s = castModel<GlassworkPluck>();
	m_decayKnob->setModel(&s->m_decay);
	m_dampingKnob->setModel(&s->m_damping);
	m_brightKnob->setModel(&s->m_bright);
	m_pickKnob->setModel(&s->m_pick);
	m_gainKnob->setModel(&s->m_gain);
}

} // namespace gui


extern "C"
{

// necessary for getting instance out of shared lib
PLUGIN_EXPORT Plugin* lmms_plugin_main(Model* model, void*)
{
	return new GlassworkPluck(static_cast<InstrumentTrack*>(model));
}

}

} // namespace lmms
