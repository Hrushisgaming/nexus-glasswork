/*
 * GlassworkPluck.h - Glasswork Pluck: Karplus-Strong plucked string synthesizer
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#ifndef LMMS_GLASSWORK_PLUCK_H
#define LMMS_GLASSWORK_PLUCK_H

#include "AutomatableModel.h"
#include "Instrument.h"
#include "InstrumentView.h"

namespace lmms
{

class NotePlayHandle;

namespace gui
{
class GlassworkPluckView;
class Knob;
}

class GlassworkPluck : public Instrument
{
	Q_OBJECT
public:
	GlassworkPluck(InstrumentTrack* instrumentTrack);
	~GlassworkPluck() override = default;

	void playNote(NotePlayHandle* n, SampleFrame* workingBuffer) override;
	void deleteNotePluginData(NotePlayHandle* n) override;

	void saveSettings(QDomDocument& doc, QDomElement& elem) override;
	void loadSettings(const QDomElement& elem) override;

	QString nodeName() const override;
	float desiredReleaseTimeMs() const override { return 60.f; }

	gui::PluginView* instantiateView(QWidget* parent) override;

private:
	FloatModel m_decay;
	FloatModel m_damping;
	FloatModel m_bright;
	FloatModel m_pick;
	FloatModel m_gain;

	friend class gui::GlassworkPluckView;
};

namespace gui
{

class GlassworkPluckView : public InstrumentViewFixedSize
{
	Q_OBJECT
public:
	GlassworkPluckView(Instrument* instrument, QWidget* parent);
	~GlassworkPluckView() override = default;

private:
	void modelChanged() override;

	Knob* m_decayKnob;
	Knob* m_dampingKnob;
	Knob* m_brightKnob;
	Knob* m_pickKnob;
	Knob* m_gainKnob;
};

} // namespace gui

} // namespace lmms

#endif // LMMS_GLASSWORK_PLUCK_H
