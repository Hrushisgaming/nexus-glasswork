/*
 * GlassworkChorus.cpp - Glasswork Chorus: lush stereo chorus (two modulated delay voices per channel)
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#include "GlassworkChorus.h"

#include <QDomElement>
#include <QGridLayout>

#include <algorithm>
#include <cmath>

#include "AudioEngine.h"
#include "Engine.h"
#include "GlassworkDsp.h"
#include "GlassworkUi.h"
#include "Knob.h"
#include "embed.h"
#include "plugin_export.h"

namespace lmms
{

extern "C"
{

Plugin::Descriptor PLUGIN_EXPORT glassworkchorus_plugin_descriptor =
{
	LMMS_STRINGIFY(PLUGIN_NAME),
	"Glasswork Chorus",
	QT_TRANSLATE_NOOP("PluginBrowser", "Lush stereo chorus with two modulated delay voices per channel"),
	"Glasswork",
	0x0100,
	Plugin::Type::Effect,
	new PixmapLoader("lmms-plugin-logo"),
	nullptr,
	nullptr,
};

}


GlassworkChorusControls::GlassworkChorusControls(GlassworkChorusEffect* effect) :
	EffectControls(effect),
	m_effect(effect),
	m_rate(0.6f, 0.05f, 8.0f, 0.01f, this, tr("Rate")),
	m_depth(5.0f, 0.0f, 12.0f, 0.01f, this, tr("Depth")),
	m_delay(14.0f, 4.0f, 30.0f, 0.1f, this, tr("Delay")),
	m_feedback(0.0f, 0.0f, 60.0f, 0.1f, this, tr("Feedback")),
	m_width(100.0f, 0.0f, 100.0f, 0.1f, this, tr("Stereo width"))
{
}


void GlassworkChorusControls::saveSettings(QDomDocument& doc, QDomElement& parent)
{
	m_rate.saveSettings(doc, parent, "rate");
	m_depth.saveSettings(doc, parent, "depth");
	m_delay.saveSettings(doc, parent, "delay");
	m_feedback.saveSettings(doc, parent, "feedback");
	m_width.saveSettings(doc, parent, "width");
}


void GlassworkChorusControls::loadSettings(const QDomElement& parent)
{
	m_rate.loadSettings(parent, "rate");
	m_depth.loadSettings(parent, "depth");
	m_delay.loadSettings(parent, "delay");
	m_feedback.loadSettings(parent, "feedback");
	m_width.loadSettings(parent, "width");
}


gui::EffectControlDialog* GlassworkChorusControls::createView()
{
	return new gui::GlassworkChorusDialog(this);
}


GlassworkChorusEffect::GlassworkChorusEffect(Model* parent, const Descriptor::SubPluginFeatures::Key* key) :
	Effect(&glassworkchorus_plugin_descriptor, parent, key),
	m_controls(this),
	m_lineL(BufferSize, 0.0f),
	m_lineR(BufferSize, 0.0f)
{
}


float GlassworkChorusEffect::readDelayed(const std::vector<float>& line, float delaySamples) const
{
	float pos = static_cast<float>(m_write) - std::clamp(delaySamples, 1.0f, static_cast<float>(BufferSize - 2));
	while (pos < 0.0f) { pos += static_cast<float>(BufferSize); }
	const int i0 = static_cast<int>(pos) & BufferMask;
	const int i1 = (i0 + 1) & BufferMask;
	const float frac = pos - std::floor(pos);
	return line[static_cast<size_t>(i0)] * (1.0f - frac) + line[static_cast<size_t>(i1)] * frac;
}


Effect::ProcessStatus GlassworkChorusEffect::processImpl(SampleFrame* buf, const f_cnt_t frames)
{
	const float sampleRate = Engine::audioEngine()->outputSampleRate();
	const double phaseInc = static_cast<double>(m_controls.m_rate.value()) / sampleRate;
	const float msToSamples = sampleRate * 0.001f;
	const float baseDelay = m_controls.m_delay.value() * msToSamples;
	const float depth = m_controls.m_depth.value() * msToSamples;
	const float feedback = m_controls.m_feedback.value() * 0.01f;
	const double widthPhase = static_cast<double>(m_controls.m_width.value()) * 0.01 * 0.25; // L/R LFO offset, up to a quarter cycle

	const float d = dryLevel();
	const float w = wetLevel();

	for (f_cnt_t f = 0; f < frames; ++f)
	{
		const float lfoL = std::sin(gw::TwoPi * static_cast<float>(m_phase));
		const float lfoR = std::sin(gw::TwoPi * static_cast<float>(std::fmod(m_phase + widthPhase, 1.0)));

		const float wetL = 0.5f * (readDelayed(m_lineL, baseDelay + depth * lfoL) + readDelayed(m_lineL, baseDelay - depth * lfoL));
		const float wetR = 0.5f * (readDelayed(m_lineR, baseDelay + depth * lfoR) + readDelayed(m_lineR, baseDelay - depth * lfoR));

		auto& frame = buf[f];
		const float inL = frame[0];
		const float inR = frame[1];

		m_lineL[static_cast<size_t>(m_write)] = inL + feedback * wetL;
		m_lineR[static_cast<size_t>(m_write)] = inR + feedback * wetR;
		m_write = (m_write + 1) & BufferMask;

		m_phase += phaseInc;
		if (m_phase >= 1.0) { m_phase -= 1.0; }

		frame[0] = inL * d + wetL * w;
		frame[1] = inR * d + wetR * w;
	}

	return ProcessStatus::ContinueIfNotQuiet;
}


namespace gui
{

GlassworkChorusDialog::GlassworkChorusDialog(GlassworkChorusControls* controls) :
	EffectControlDialog(controls)
{
	auto* grid = new QGridLayout(this);
	grid->setContentsMargins(14, 12, 14, 12);
	grid->setSpacing(10);

	auto* rate = gwui::makeKnob(this, tr("RATE"), tr("Rate:"), " Hz");
	rate->setModel(&controls->m_rate);
	auto* depth = gwui::makeKnob(this, tr("DEPTH"), tr("Depth:"), " ms");
	depth->setModel(&controls->m_depth);
	auto* delay = gwui::makeKnob(this, tr("DELAY"), tr("Delay:"), " ms");
	delay->setModel(&controls->m_delay);
	auto* feedback = gwui::makeKnob(this, tr("FEEDBACK"), tr("Feedback:"), "%");
	feedback->setModel(&controls->m_feedback);
	auto* width = gwui::makeKnob(this, tr("WIDTH"), tr("Stereo width:"), "%");
	width->setModel(&controls->m_width);

	grid->addWidget(rate, 0, 0, Qt::AlignHCenter);
	grid->addWidget(depth, 0, 1, Qt::AlignHCenter);
	grid->addWidget(delay, 0, 2, Qt::AlignHCenter);
	grid->addWidget(feedback, 1, 0, Qt::AlignHCenter);
	grid->addWidget(width, 1, 1, Qt::AlignHCenter);
	grid->setSizeConstraint(QLayout::SetFixedSize);
}

} // namespace gui


extern "C"
{

// necessary for getting instance out of shared lib
PLUGIN_EXPORT Plugin* lmms_plugin_main(Model* parent, void* data)
{
	return new GlassworkChorusEffect(parent, static_cast<const Plugin::Descriptor::SubPluginFeatures::Key*>(data));
}

}

} // namespace lmms
