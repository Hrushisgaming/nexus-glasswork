/*
 * GlassworkChorus.h - Glasswork Chorus: lush stereo chorus (two modulated delay voices per channel)
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#ifndef LMMS_GLASSWORK_CHORUS_H
#define LMMS_GLASSWORK_CHORUS_H

#include <vector>

#include "Effect.h"
#include "EffectControlDialog.h"
#include "EffectControls.h"

namespace lmms
{

class GlassworkChorusEffect;

namespace gui
{
class GlassworkChorusDialog;
}

class GlassworkChorusControls : public EffectControls
{
	Q_OBJECT
public:
	GlassworkChorusControls(GlassworkChorusEffect* effect);
	~GlassworkChorusControls() override = default;

	void saveSettings(QDomDocument& doc, QDomElement& parent) override;
	void loadSettings(const QDomElement& parent) override;
	inline QString nodeName() const override { return "GlassworkChorusControls"; }
	gui::EffectControlDialog* createView() override;
	int controlCount() override { return 5; }

private:
	GlassworkChorusEffect* m_effect;
	FloatModel m_rate;
	FloatModel m_depth;
	FloatModel m_delay;
	FloatModel m_feedback;
	FloatModel m_width;

	friend class gui::GlassworkChorusDialog;
	friend class GlassworkChorusEffect;
};


class GlassworkChorusEffect : public Effect
{
public:
	GlassworkChorusEffect(Model* parent, const Descriptor::SubPluginFeatures::Key* key);
	~GlassworkChorusEffect() override = default;

	ProcessStatus processImpl(SampleFrame* buf, const f_cnt_t frames) override;

	EffectControls* controls() override { return &m_controls; }

private:
	static constexpr int BufferSize = 8192; // power of two; ~170 ms at 48 kHz
	static constexpr int BufferMask = BufferSize - 1;

	float readDelayed(const std::vector<float>& line, float delaySamples) const;

	GlassworkChorusControls m_controls;
	std::vector<float> m_lineL;
	std::vector<float> m_lineR;
	int m_write = 0;
	double m_phase = 0.0;

	friend class GlassworkChorusControls;
};


namespace gui
{

class GlassworkChorusDialog : public EffectControlDialog
{
	Q_OBJECT
public:
	GlassworkChorusDialog(GlassworkChorusControls* controls);
	~GlassworkChorusDialog() override = default;
};

} // namespace gui

} // namespace lmms

#endif // LMMS_GLASSWORK_CHORUS_H
