/*
 * GlassworkDsp.h - small header-only DSP helpers shared by Glasswork's own instruments and effects
 *
 * Part of Glasswork, a fork of LMMS. Licensed under the GNU GPL v2 or later, like LMMS.
 */

#ifndef LMMS_GLASSWORK_DSP_H
#define LMMS_GLASSWORK_DSP_H

#include <algorithm>
#include <cmath>
#include <cstdint>

#include "NotePlayHandle.h"
#include "SampleFrame.h"

namespace lmms::gw
{

constexpr float TwoPi = 6.28318530717958647692f;
constexpr float Pi = 3.14159265358979323846f;

//! Band-limited step correction (polyBLEP) for saw and square oscillators.
inline float polyBlep(float t, float dt)
{
	if (t < dt)
	{
		t /= dt;
		return t + t - t * t - 1.0f;
	}
	if (t > 1.0f - dt)
	{
		t = (t - 1.0f) / dt;
		return t * t + t + t + 1.0f;
	}
	return 0.0f;
}

inline float wrap01(float x) { return x - std::floor(x); }

inline float sawBlep(float phase, float dt) { return 2.0f * phase - 1.0f - polyBlep(phase, dt); }

inline float squareBlep(float phase, float dt)
{
	float v = phase < 0.5f ? 1.0f : -1.0f;
	v += polyBlep(phase, dt);
	v -= polyBlep(wrap01(phase + 0.5f), dt);
	return v;
}

//! Tiny deterministic random number generator (no allocation, no locking, safe on the audio thread).
struct Rng
{
	uint32_t state;
	explicit Rng(uint32_t seed = 22222u) : state(seed ? seed : 1u) {}
	uint32_t next()
	{
		state = state * 1664525u + 1013904223u;
		return state;
	}
	float uni() { return static_cast<float>(next() >> 8) * (1.0f / 16777216.0f); } // [0, 1)
	float bi() { return uni() * 2.0f - 1.0f; }                                       // [-1, 1)
};

//! Zero-delay-feedback state variable filter (Zavalishin). g = tan(pi*fc/fs), k = 1/Q.
struct Svf
{
	float ic1 = 0.0f;
	float ic2 = 0.0f;
	float lp = 0.0f;
	float bp = 0.0f;
	float hp = 0.0f;

	void process(float x, float g, float k)
	{
		const float a1 = 1.0f / (1.0f + g * (g + k));
		const float a2 = g * a1;
		const float a3 = g * a2;
		const float v3 = x - ic2;
		const float v1 = a1 * ic1 + a2 * v3;
		const float v2 = ic2 + a2 * ic1 + a3 * v3;
		ic1 = 2.0f * v1 - ic1;
		ic2 = 2.0f * v2 - ic2;
		bp = v1;
		lp = v2;
		hp = x - k * v1 - v2;
	}
};

inline float svfG(float cutoffHz, float sampleRate)
{
	return std::tan(Pi * std::clamp(cutoffHz, 5.0f, sampleRate * 0.45f) / sampleRate);
}

//! Simple 4-pole transistor-ladder style low-pass filter with tanh feedback. res: 0..1
struct Ladder
{
	float s[4] = {0.0f, 0.0f, 0.0f, 0.0f};

	float process(float in, float cutoffHz, float res, float sampleRate)
	{
		const float f = std::clamp(cutoffHz / sampleRate, 0.0005f, 0.18f);
		const float g = 1.0f - std::exp(-TwoPi * f);
		const float k = std::clamp(res, 0.0f, 1.0f) * 3.8f;
		const float x = std::tanh(in - k * s[3]);
		s[0] += g * (x - s[0]);
		s[1] += g * (s[0] - s[1]);
		s[2] += g * (s[1] - s[2]);
		s[3] += g * (s[2] - s[3]);
		return s[3];
	}
};

//! Linear fade-out over the release phase of a note, like LMMS's own Kicker does.
inline void applyLinearRelease(NotePlayHandle* n, SampleFrame* buf, f_cnt_t offset, f_cnt_t frames, float desiredReleaseFrames)
{
	if (!n->isReleased()) { return; }
	f_cnt_t current = n->releaseFramesDone();
	const f_cnt_t start = n->framesBeforeRelease();
	for (f_cnt_t f = start; f < frames; ++f, ++current)
	{
		const float gain = current < desiredReleaseFrames ? (1.0f - (static_cast<float>(current) / desiredReleaseFrames)) : 0.0f;
		buf[offset + f][0] *= gain;
		buf[offset + f][1] *= gain;
	}
}

} // namespace lmms::gw

#endif // LMMS_GLASSWORK_DSP_H
