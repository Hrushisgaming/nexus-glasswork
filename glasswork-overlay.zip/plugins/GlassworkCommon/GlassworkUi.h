/*
 * GlassworkUi.h - small GUI helper shared by Glasswork's own instruments and effects
 */

#ifndef LMMS_GLASSWORK_UI_H
#define LMMS_GLASSWORK_UI_H

#include <QString>
#include <QWidget>

#include "Knob.h"

namespace lmms::gui::gwui
{

inline Knob* makeKnob(QWidget* parent, const QString& label, const QString& hint, const QString& unit)
{
	auto* knob = new Knob(KnobType::Bright26, label, parent);
	knob->setHintText(hint, unit);
	return knob;
}

} // namespace lmms::gui::gwui

#endif // LMMS_GLASSWORK_UI_H
